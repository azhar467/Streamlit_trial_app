# Artifactory Setup Guide 🔧

## Problem: Protocol Broken Error

If you're getting a "protocol broken" error when installing Flask, it's because you're in a corporate environment using Artifactory as your Python package repository.

## Quick Fixes (Try These First)

### Solution 1: Manual Installation from Artifactory

If Flask is available in your Artifactory, install directly:

```bash
# Find your Artifactory URL (ask your DevOps team or check existing projects)
pip install Flask==3.0.0 --index-url https://YOUR-ARTIFACTORY-URL/artifactory/api/pypi/pypi-virtual/simple --trusted-host YOUR-ARTIFACTORY-URL

pip install flask-cors==4.0.0 --index-url https://YOUR-ARTIFACTORY-URL/artifactory/api/pypi/pypi-virtual/simple --trusted-host YOUR-ARTIFACTORY-URL
```

### Solution 2: Configure pip to Always Use Artifactory

Create a pip configuration file:

**For Linux/Mac:**
```bash
mkdir -p ~/.pip
nano ~/.pip/pip.conf
```

**For Windows:**
```cmd
mkdir %APPDATA%\pip
notepad %APPDATA%\pip\pip.ini
```

**Add this content** (replace with your actual Artifactory URL):
```ini
[global]
index-url = https://YOUR-ARTIFACTORY-URL/artifactory/api/pypi/pypi-virtual/simple
trusted-host = YOUR-ARTIFACTORY-URL
timeout = 60

[install]
trusted-host = YOUR-ARTIFACTORY-URL
```

### Solution 3: Use Project-Level Configuration

Copy `pip.conf.example` to `pip.conf` (or `pip.ini` on Windows) in the project directory and edit it with your Artifactory URL.

## Step-by-Step Artifactory Setup

### Step 1: Get Your Artifactory URL

Ask your DevOps team or check existing projects for the Artifactory URL. It usually looks like:
- `https://artifactory.company.com`
- `https://artifacts.company.com`
- `https://nexus.company.com` (if using Nexus instead)

### Step 2: Get Your Credentials (if needed)

Some Artifactory setups require authentication:
- Username: Your corporate username
- Password: Your corporate password or API token

### Step 3: Configure pip

**Option A: Using ~/.pip/pip.conf (Recommended)**

Create the file with your Artifactory details:

```ini
[global]
# Without authentication
index-url = https://artifactory.mycompany.com/artifactory/api/pypi/pypi-virtual/simple
trusted-host = artifactory.mycompany.com
timeout = 60

# OR with authentication
# index-url = https://username:password@artifactory.mycompany.com/artifactory/api/pypi/pypi-virtual/simple
# trusted-host = artifactory.mycompany.com
```

**Option B: Using Environment Variables**

```bash
# Linux/Mac
export PIP_INDEX_URL=https://artifactory.mycompany.com/artifactory/api/pypi/pypi-virtual/simple
export PIP_TRUSTED_HOST=artifactory.mycompany.com

# Windows
set PIP_INDEX_URL=https://artifactory.mycompany.com/artifactory/api/pypi/pypi-virtual/simple
set PIP_TRUSTED_HOST=artifactory.mycompany.com
```

**Option C: Use pip arguments directly**

```bash
pip install -r requirements.txt \
  --index-url https://artifactory.mycompany.com/artifactory/api/pypi/pypi-virtual/simple \
  --trusted-host artifactory.mycompany.com
```

### Step 4: Test Installation

```bash
pip install Flask==3.0.0
```

If successful, you'll see Flask download from your Artifactory.

## Common Issues & Solutions

### Issue 1: SSL Certificate Error

**Error:** `SSL: CERTIFICATE_VERIFY_FAILED`

**Solution:** Add certificate or disable verification (not recommended for production)

```bash
# Temporary fix (insecure)
pip install --trusted-host artifactory.mycompany.com Flask

# Better fix: Add certificate
pip install --cert /path/to/certificate.pem Flask
```

Add to pip.conf:
```ini
[global]
cert = /path/to/company-cert.pem
```

### Issue 2: Authentication Required

**Error:** `401 Unauthorized`

**Solution:** Add credentials to URL or use API token

```bash
# Using credentials in URL
pip install --index-url https://username:password@artifactory.com/... Flask

# Using API token (recommended)
pip install --index-url https://username:API_TOKEN@artifactory.com/... Flask
```

### Issue 3: Repository Not Found

**Error:** `Could not find a version that satisfies the requirement`

**Solution:** Check the repository name

Common repository paths:
- `/artifactory/api/pypi/pypi-virtual/simple`
- `/artifactory/api/pypi/pypi/simple`
- `/artifactory/api/pypi/pypi-local/simple`

Ask your DevOps team for the correct path.

### Issue 4: Network/Proxy Issues

**Error:** `Connection timeout` or `Protocol broken`

**Solution:** Increase timeout and configure proxy

```bash
pip install --timeout 120 Flask

# Or add to pip.conf
[global]
timeout = 120

# If behind corporate proxy
[global]
proxy = http://proxy.company.com:8080
```

## Alternative: Manual Installation

If all else fails, download packages manually:

### Option 1: Download from Artifactory Web UI

1. Open your Artifactory in a browser
2. Navigate to the Python repository
3. Search for Flask and flask-cors
4. Download the `.whl` files
5. Install locally:

```bash
pip install Flask-3.0.0-py3-none-any.whl
pip install Flask_Cors-4.0.0-py2.py3-none-any.whl
```

### Option 2: Use Artifactory API

```bash
# Download using curl/wget
curl -u username:password https://artifactory.com/artifactory/pypi-virtual/Flask/3.0.0/Flask-3.0.0-py3-none-any.whl -O

# Then install
pip install Flask-3.0.0-py3-none-any.whl
```

## Complete Working Example

Here's a complete example for a typical corporate setup:

```bash
# 1. Create pip config
mkdir -p ~/.pip
cat > ~/.pip/pip.conf << EOF
[global]
index-url = https://artifactory.mycompany.com/artifactory/api/pypi/pypi-virtual/simple
trusted-host = artifactory.mycompany.com
timeout = 120

[install]
trusted-host = artifactory.mycompany.com
EOF

# 2. Test configuration
pip config list

# 3. Install packages
pip install Flask==3.0.0
pip install flask-cors==4.0.0

# 4. Run the application
python app.py
```

## Updated Installation Script

I've updated `run.sh` and `run.bat` to handle Artifactory automatically. They will:
1. Check for pip.conf/pip.ini in project directory
2. Check for ~/.pip/pip.conf configuration
3. Fall back to default PyPI
4. Try alternative installation if first attempt fails

## Getting Help from Your Team

If you're still having issues, ask your DevOps team:

1. "What's our Artifactory URL for Python packages?"
2. "Do I need authentication for pip/Artifactory?"
3. "What's the correct repository path for PyPI packages?"
4. "Do we have Flask 3.0.0 and flask-cors 4.0.0 in Artifactory?"
5. "Is there a company pip.conf template I should use?"

## Quick Reference Commands

```bash
# Show pip configuration
pip config list

# Test Artifactory connection
pip search Flask --index-url https://YOUR-ARTIFACTORY/artifactory/api/pypi/pypi-virtual/simple

# Install with custom index
pip install Flask --index-url https://YOUR-ARTIFACTORY/artifactory/api/pypi/pypi-virtual/simple --trusted-host YOUR-ARTIFACTORY

# Install without SSL verification (temporary)
pip install --trusted-host YOUR-ARTIFACTORY Flask

# Show installed packages
pip list

# Install from local wheel file
pip install Flask-3.0.0-py3-none-any.whl
```

## Need More Help?

1. Check the `pip.conf.example` file in the project
2. Review your company's internal documentation for pip/Artifactory
3. Contact your DevOps or Platform team
4. Check if there's a company-wide pip configuration template

---

Once you have pip configured correctly, the migration tool will work perfectly! 🚀
