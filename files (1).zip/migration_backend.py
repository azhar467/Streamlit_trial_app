"""
Migration Backend - Adapted for Web UI
This module provides web-friendly functions for the migration tool
"""

import urllib.request
import urllib.parse
import urllib.error
import json
import base64
import re
import os
import sys
from pathlib import Path

# Import core functions from migration.py
# We'll adapt these for web use

# Configuration
BASE_URL = ""
TOKEN = ""
PROJECT_NAMES = {}

JIRA_ID = "1293"
UPGRADE_TYPE = "java17-migration"
FEATURE_BRANCH = f"task-{JIRA_ID}-{UPGRADE_TYPE}"
SOURCE_BRANCH = "develop"
MR_TITLE = f"TASK-{JIRA_ID}: java migration"

TARGET_PARENT_VERSION = "1.8.3"
NEW_DEFAULT_PLATFORM = "arn:aws:elasticbeanstalk:us-east-1::platform/Corretto 17 running on 64bit Amazon Linux 2/3.10.3"


def load_configuration():
    """Load configuration from .env file"""
    global BASE_URL, TOKEN, PROJECT_NAMES
    
    config = {
        'base_url': '',
        'token': '',
        'projects': {},
        'token_valid': False
    }
    
    # Load from .env file
    env_path = Path('.env')
    if not env_path.exists():
        raise Exception(".env file not found. Please create one with GITLAB_TOKEN and project definitions.")
    
    with open(env_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            if '=' in line:
                key, value = line.split('=', 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                
                # Load token
                if key in ('GITLAB_TOKEN', 'TOKEN'):
                    TOKEN = value
                    config['token'] = value
                
                # Load base URL
                elif key in ('BASE_URL', 'GITLAB_BASE_URL', 'GITLAB_URL'):
                    BASE_URL = value.rstrip('/')
                    config['base_url'] = BASE_URL
                
                # Load projects
                elif key.startswith('PROJECT_'):
                    try:
                        project_id = int(key.replace('PROJECT_', ''))
                        PROJECT_NAMES[project_id] = value
                        config['projects'][str(project_id)] = value
                    except ValueError:
                        pass
    
    if not TOKEN:
        raise Exception("No GITLAB_TOKEN found in .env file")
    
    if not BASE_URL:
        raise Exception("No BASE_URL found in .env file")
    
    if not PROJECT_NAMES:
        raise Exception("No projects found in .env file")
    
    # Validate token
    try:
        validation = validate_token(TOKEN, BASE_URL)
        config['token_valid'] = validation
    except Exception as e:
        raise Exception(f"Token validation failed: {str(e)}")
    
    return config


def validate_token(token, base_url):
    """Validate GitLab token"""
    try:
        url = f"{base_url}/api/v4/user"
        req = urllib.request.Request(url)
        req.add_header("PRIVATE-TOKEN", token)
        
        with urllib.request.urlopen(req, timeout=10) as response:
            if response.status == 200:
                return True
        return False
    except Exception:
        return False


def api_call(endpoint, method="GET", data=None):
    """Make API call to GitLab"""
    url = f"{BASE_URL}/api/v4/{endpoint}"
    
    req = urllib.request.Request(url)
    req.add_header("PRIVATE-TOKEN", TOKEN)
    req.add_header("Content-Type", "application/json")
    
    if method != "GET":
        req.method = method
    
    if data:
        req.data = json.dumps(data).encode('utf-8')
    
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        try:
            error_json = json.loads(error_body)
            return {"error": True, "status": e.code, "details": error_json}
        except:
            return {"error": True, "status": e.code, "details": error_body}
    except Exception as e:
        return {"error": True, "details": str(e)}


def update_parent_block(match):
    """Update parent version in POM"""
    content = match.group(0)
    return re.sub(r"<version>[\d.]+</version>", f"<version>{TARGET_PARENT_VERSION}</version>", content, count=1)


def preview_changes(project_ids, file_types):
    """Preview changes for selected projects"""
    previews = []
    
    for pid in project_ids:
        project_info = api_call(f"projects/{pid}")
        p_name = project_info.get('name', f"ID:{pid}") if isinstance(project_info, dict) else f"ID:{pid}"
        
        project_preview = {
            'project_id': pid,
            'project_name': p_name,
            'files': []
        }
        
        # Check branch
        br_check = api_call(f"projects/{pid}/repository/branches/{urllib.parse.quote(FEATURE_BRANCH, safe='')}")
        current_ref = FEATURE_BRANCH if isinstance(br_check, dict) and "name" in br_check else SOURCE_BRANCH
        
        # Preview POM changes
        if 'pom' in file_types:
            res = api_call(f"projects/{pid}/repository/files/{urllib.parse.quote('pom.xml', safe='')}?ref={urllib.parse.quote(current_ref, safe='')}")
            if isinstance(res, dict) and "content" in res:
                orig = base64.b64decode(res['content']).decode('utf-8')
                upd = re.sub(r"<(java\.version|maven\.compiler\.(source|target|release))>11</\1>", r"<\1>17</\1>", orig)
                if "<parent>" in upd:
                    upd = re.sub(r"<parent>[\s\S]*?</parent>", update_parent_block, upd)
                
                if orig != upd:
                    project_preview['files'].append({
                        'file': 'pom.xml',
                        'status': 'modified',
                        'changes': get_change_summary(orig, upd)
                    })
        
        # Preview CI changes
        if 'ci' in file_types:
            res = api_call(f"projects/{pid}/repository/files/{urllib.parse.quote('.gitlab-ci.yml', safe='')}?ref={urllib.parse.quote(current_ref, safe='')}")
            if isinstance(res, dict) and "content" in res:
                orig = base64.b64decode(res['content']).decode('utf-8')
                upd = re.sub(r"^\s*image:.*(\n|$)", "", orig, flags=re.MULTILINE)
                
                if orig != upd:
                    project_preview['files'].append({
                        'file': '.gitlab-ci.yml',
                        'status': 'modified',
                        'changes': get_change_summary(orig, upd)
                    })
        
        # Preview EB changes
        if 'eb' in file_types:
            path = urllib.parse.quote(".elasticbeanstalk/config.yml", safe='')
            res = api_call(f"projects/{pid}/repository/files/{path}?ref={urllib.parse.quote(current_ref, safe='')}")
            if isinstance(res, dict) and "content" in res:
                orig = base64.b64decode(res['content']).decode('utf-8')
                upd = re.sub(r"(default_platform:\s*).*$", f"default_platform: {NEW_DEFAULT_PLATFORM}", orig, flags=re.MULTILINE)
                
                if orig != upd:
                    project_preview['files'].append({
                        'file': '.elasticbeanstalk/config.yml',
                        'status': 'modified',
                        'changes': get_change_summary(orig, upd)
                    })
        
        if project_preview['files']:
            previews.append(project_preview)
    
    return previews


def get_change_summary(old_content, new_content):
    """Get summary of changes between two file versions"""
    import difflib
    
    diff = list(difflib.ndiff(old_content.splitlines(), new_content.splitlines()))
    added = len([l for l in diff if l.startswith('+ ')])
    removed = len([l for l in diff if l.startswith('- ')])
    
    return {
        'added': added,
        'removed': removed,
        'total': added + removed
    }


def process_project_web(pid, file_types, mode, auto_commit, log_callback=None):
    """Process a single project for web UI"""
    def log(msg, level='INFO'):
        if log_callback:
            log_callback(msg, level)
    
    result = {
        'project_id': pid,
        'project_name': '',
        'success': False,
        'committed': False,
        'error': None
    }
    
    try:
        # Get project info
        project_info = api_call(f"projects/{pid}")
        p_name = project_info.get('name', f"ID:{pid}") if isinstance(project_info, dict) else f"ID:{pid}"
        result['project_name'] = p_name
        
        log(f"Processing {p_name}...", 'INFO')
        
        # Check/create branch
        br_check = api_call(f"projects/{pid}/repository/branches/{urllib.parse.quote(FEATURE_BRANCH, safe='')}")
        
        if not isinstance(br_check, dict) or br_check.get("error"):
            log(f"Creating feature branch: {FEATURE_BRANCH}", 'INFO')
            br_create = api_call(f"projects/{pid}/repository/branches", "POST", {
                "branch": FEATURE_BRANCH,
                "ref": SOURCE_BRANCH
            })
            
            if isinstance(br_create, dict) and br_create.get("error"):
                result['error'] = f"Failed to create branch: {br_create.get('details')}"
                return result
        
        current_ref = FEATURE_BRANCH
        actions = []
        
        # Prepare file changes
        if 'pom' in file_types:
            res = api_call(f"projects/{pid}/repository/files/{urllib.parse.quote('pom.xml', safe='')}?ref={urllib.parse.quote(current_ref, safe='')}")
            if isinstance(res, dict) and "content" in res:
                orig = base64.b64decode(res['content']).decode('utf-8')
                upd = re.sub(r"<(java\.version|maven\.compiler\.(source|target|release))>11</\1>", r"<\1>17</\1>", orig)
                if "<parent>" in upd:
                    upd = re.sub(r"<parent>[\s\S]*?</parent>", update_parent_block, upd)
                
                if orig != upd:
                    actions.append({
                        "action": "update",
                        "file_path": "pom.xml",
                        "content": base64.b64encode(upd.encode('utf-8')).decode('ascii')
                    })
                    log("Updated pom.xml", 'INFO')
        
        if 'ci' in file_types:
            res = api_call(f"projects/{pid}/repository/files/{urllib.parse.quote('.gitlab-ci.yml', safe='')}?ref={urllib.parse.quote(current_ref, safe='')}")
            if isinstance(res, dict) and "content" in res:
                orig = base64.b64decode(res['content']).decode('utf-8')
                upd = re.sub(r"^\s*image:.*(\n|$)", "", orig, flags=re.MULTILINE)
                
                if orig != upd:
                    actions.append({
                        "action": "update",
                        "file_path": ".gitlab-ci.yml",
                        "content": base64.b64encode(upd.encode('utf-8')).decode('ascii')
                    })
                    log("Updated .gitlab-ci.yml", 'INFO')
        
        if 'eb' in file_types:
            path = ".elasticbeanstalk/config.yml"
            res = api_call(f"projects/{pid}/repository/files/{urllib.parse.quote(path, safe='')}?ref={urllib.parse.quote(current_ref, safe='')}")
            if isinstance(res, dict) and "content" in res:
                orig = base64.b64decode(res['content']).decode('utf-8')
                upd = re.sub(r"(default_platform:\s*).*$", f"default_platform: {NEW_DEFAULT_PLATFORM}", orig, flags=re.MULTILINE)
                
                if orig != upd:
                    actions.append({
                        "action": "update",
                        "file_path": path,
                        "content": base64.b64encode(upd.encode('utf-8')).decode('ascii')
                    })
                    log("Updated .elasticbeanstalk/config.yml", 'INFO')
        
        # Commit changes
        if actions and auto_commit:
            log("Committing changes...", 'INFO')
            commit_payload = {
                "branch": FEATURE_BRANCH,
                "commit_message": MR_TITLE,
                "actions": actions
            }
            
            commit_result = api_call(f"projects/{pid}/repository/commits", "POST", commit_payload)
            
            if isinstance(commit_result, dict) and not commit_result.get("error"):
                result['committed'] = True
                result['success'] = True
                log("Changes committed successfully", 'SUCCESS')
            else:
                result['error'] = f"Commit failed: {commit_result.get('details')}"
                log(result['error'], 'ERROR')
        elif actions:
            result['success'] = True
            result['committed'] = False
            log("Changes prepared (not committed)", 'INFO')
        else:
            result['success'] = True
            log("No changes needed", 'INFO')
        
        return result
        
    except Exception as e:
        result['error'] = str(e)
        log(f"Error: {str(e)}", 'ERROR')
        return result


def perform_rollback_web(rollback_file, log_callback=None):
    """Perform rollback from web UI"""
    def log(msg, level='INFO'):
        if log_callback:
            log_callback(msg, level)
    
    # This would implement rollback logic
    # For now, returning a placeholder
    log("Rollback functionality coming soon", 'WARN')
    
    return {
        'success': False,
        'error': 'Rollback not yet implemented in web UI'
    }
