@echo off
REM Quick Artifactory Installation (Windows)
REM Usage: install_artifactory.bat <ARTIFACTORY_URL>
REM Example: install_artifactory.bat https://artifactory.mycompany.com

if "%~1"=="" (
    echo ==========================================
    echo Quick Artifactory Installation
    echo ==========================================
    echo.
    echo Usage: %~nx0 ^<ARTIFACTORY_URL^>
    echo.
    echo Example:
    echo   %~nx0 https://artifactory.mycompany.com
    echo.
    echo Or enter your Artifactory URL now...
    echo.
    set /p ARTIFACTORY_URL="Enter your Artifactory URL: "
) else (
    set ARTIFACTORY_URL=%~1
)

REM Remove trailing slash if present
if "%ARTIFACTORY_URL:~-1%"=="/" set ARTIFACTORY_URL=%ARTIFACTORY_URL:~0,-1%

echo.
echo Using Artifactory: %ARTIFACTORY_URL%
echo.

REM Extract hostname for trusted-host
for /f "tokens=3 delims=:/" %%a in ("%ARTIFACTORY_URL%") do set ARTIFACTORY_HOST=%%a

echo Installing Flask from Artifactory...
pip install Flask==3.0.0 --index-url %ARTIFACTORY_URL%/artifactory/api/pypi/pypi-virtual/simple --trusted-host %ARTIFACTORY_HOST%

if errorlevel 1 (
    echo Failed with pypi-virtual, trying pypi...
    pip install Flask==3.0.0 --index-url %ARTIFACTORY_URL%/artifactory/api/pypi/pypi/simple --trusted-host %ARTIFACTORY_HOST%
)

echo.
echo Installing flask-cors from Artifactory...
pip install flask-cors==4.0.0 --index-url %ARTIFACTORY_URL%/artifactory/api/pypi/pypi-virtual/simple --trusted-host %ARTIFACTORY_HOST%

if errorlevel 1 (
    echo Failed with pypi-virtual, trying pypi...
    pip install flask-cors==4.0.0 --index-url %ARTIFACTORY_URL%/artifactory/api/pypi/pypi/simple --trusted-host %ARTIFACTORY_HOST%
)

echo.
echo ==========================================
echo Installation complete!
echo ==========================================
echo.
echo To make this permanent, create %%APPDATA%%\pip\pip.ini with:
echo.
echo [global]
echo index-url = %ARTIFACTORY_URL%/artifactory/api/pypi/pypi-virtual/simple
echo trusted-host = %ARTIFACTORY_HOST%
echo.
pause
