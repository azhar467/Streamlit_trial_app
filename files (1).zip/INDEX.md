# 📖 GitLab Migration Tool - Documentation Index

Welcome! This index will help you find the right documentation for your situation.

## 🚀 START HERE

### New Users (First Time Setup)
1. **QUICKSTART.md** - 5-minute setup guide for new users
2. If you get errors during installation → See "Installation Issues" below

### Corporate/Artifactory Users
1. **ARTIFACTORY_QUICK_FIX.md** ⚠️ **START HERE IF YOU GET "PROTOCOL BROKEN" ERROR**
2. ARTIFACTORY_SETUP.md - Complete Artifactory configuration guide
3. Then follow QUICKSTART.md for application setup

---

## 📚 Documentation Files

### Essential Reading
| File | Purpose | When to Read |
|------|---------|--------------|
| **ARTIFACTORY_QUICK_FIX.md** | Fast fix for corporate environments | If you get "protocol broken" error |
| **QUICKSTART.md** | 5-minute setup guide | First time users |
| **README.md** | Complete documentation | When you want all the details |

### Installation Help
| File | Purpose | Use When |
|------|---------|----------|
| **ARTIFACTORY_SETUP.md** | Detailed Artifactory setup | Having trouble with corporate proxy/Artifactory |
| **pip.conf.example** | pip configuration template | Need to configure pip for Artifactory |

### Reference
| File | Purpose |
|------|---------|
| **FILE_LIST.md** | Complete file listing and architecture |
| **.env.example** | Configuration template |

---

## 🛠️ Installation Scripts

### Standard Installation
- **run.sh** (Linux/Mac) - Standard startup script
- **run.bat** (Windows) - Standard startup script
- Uses PyPI by default, falls back to manual if needed

### Artifactory Installation
- **install_artifactory.sh** (Linux/Mac) - Quick Artifactory install with URL
- **install_artifactory.bat** (Windows) - Quick Artifactory install with URL
- **install_manual.sh** (Linux/Mac) - Step-by-step manual installation
- **install_manual.bat** (Windows) - Step-by-step manual installation

### Usage Examples

**Standard (works on most systems):**
```bash
./run.sh          # Linux/Mac
run.bat           # Windows
```

**Corporate/Artifactory:**
```bash
./install_artifactory.sh https://artifactory.yourcompany.com
install_artifactory.bat https://artifactory.yourcompany.com
```

**Manual/Troubleshooting:**
```bash
./install_manual.sh          # Linux/Mac
install_manual.bat           # Windows
```

---

## 🎯 Common Scenarios

### "I'm new and want to get started quickly"
→ Read: **QUICKSTART.md**
→ Run: `./run.sh` or `run.bat`

### "I'm in a corporate environment with Artifactory"
→ Read: **ARTIFACTORY_QUICK_FIX.md** first
→ Run: `./install_artifactory.sh https://your-artifactory-url`
→ Then: `python app.py`

### "Installation keeps failing"
→ Read: **ARTIFACTORY_SETUP.md** for troubleshooting
→ Run: `./install_manual.sh` for step-by-step installation

### "I want to understand the architecture"
→ Read: **FILE_LIST.md** for complete overview
→ Read: **README.md** for detailed documentation

### "I need to configure pip for Artifactory permanently"
→ See: **pip.conf.example**
→ Guide: **ARTIFACTORY_SETUP.md** Section: "Configure pip to Always Use Artifactory"

### "I want to customize the migration settings"
→ Edit: `.env` (copy from `.env.example`)
→ Advanced: Edit `migration_backend.py` for migration logic

---

## 📁 Application Files

### Core Application
- **app.py** - Flask web server (main application)
- **migration_backend.py** - Migration logic for web UI
- **migration.py** - Original CLI script (enhanced)
- **templates/index.html** - Web interface

### Configuration
- **.env** - Your configuration (create from .env.example)
- **.env.example** - Configuration template
- **requirements.txt** - Python dependencies

---

## 🔍 Quick Reference

### Installation Issues
```
Error                          → Solution File
─────────────────────────────────────────────────────────────
"Protocol broken"              → ARTIFACTORY_QUICK_FIX.md
SSL certificate error          → ARTIFACTORY_SETUP.md
401 Unauthorized               → ARTIFACTORY_SETUP.md
Package not found              → ARTIFACTORY_SETUP.md
Connection timeout             → ARTIFACTORY_SETUP.md
Can't find .env                → Create from .env.example
```

### Application Issues
```
Issue                          → Check
─────────────────────────────────────────────────────────────
Can't connect to GitLab        → .env file (TOKEN and BASE_URL)
No projects showing            → .env file (PROJECT_XXX entries)
Port already in use            → Change port in app.py
Migration fails                → Check GitLab permissions
```

### Getting Help
1. Check the relevant documentation file above
2. Search the README.md for your error message
3. Check ARTIFACTORY_SETUP.md if in corporate environment
4. Contact your DevOps team for Artifactory URLs
5. Review migration_logs/ for detailed error logs

---

## 🎓 Learning Path

**Beginner:**
1. QUICKSTART.md - Get started
2. README.md (Introduction) - Understand features
3. Use the web UI - Learn by doing

**Intermediate:**
1. README.md (Complete) - Full documentation
2. FILE_LIST.md - Architecture overview
3. .env configuration - Customize settings

**Advanced:**
1. migration_backend.py - Modify migration logic
2. app.py - Customize web server
3. templates/index.html - Customize UI

---

## 📊 File Organization

```
migration-tool/
├── Documentation/
│   ├── INDEX.md (this file)           ← You are here
│   ├── QUICKSTART.md                   ← Start here
│   ├── README.md                       ← Full docs
│   ├── ARTIFACTORY_QUICK_FIX.md       ← Corporate users
│   ├── ARTIFACTORY_SETUP.md           ← Detailed Artifactory
│   └── FILE_LIST.md                    ← Architecture
│
├── Installation Scripts/
│   ├── run.sh / run.bat                ← Standard install
│   ├── install_artifactory.*          ← Artifactory install
│   └── install_manual.*               ← Manual install
│
├── Configuration/
│   ├── .env.example                    ← Config template
│   ├── pip.conf.example               ← pip config template
│   └── requirements.txt               ← Dependencies
│
└── Application/
    ├── app.py                          ← Web server
    ├── migration_backend.py           ← Migration logic
    ├── migration.py                   ← CLI script
    └── templates/index.html           ← Web UI
```

---

## ✅ Next Steps

1. **Identify your environment:**
   - Standard → Use QUICKSTART.md
   - Corporate/Artifactory → Use ARTIFACTORY_QUICK_FIX.md

2. **Install dependencies:**
   - Standard: `./run.sh`
   - Artifactory: `./install_artifactory.sh <URL>`
   - Manual: `./install_manual.sh`

3. **Run the application:**
   - `python app.py`
   - Open http://localhost:5000

4. **Start migrating!** 🎉

---

**Need help?** Find the right documentation using this index!

**Questions?** Check the troubleshooting sections in README.md and ARTIFACTORY_SETUP.md
