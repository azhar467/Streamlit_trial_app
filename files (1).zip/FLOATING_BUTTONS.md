# 🎯 Floating Action Buttons (FABs) Guide

## ✨ New Features Added!

Your GitLab Migration Tool now includes three powerful floating action buttons for enhanced navigation and log access!

---

## 📍 Button Locations

All three buttons appear in the **bottom-right corner** of the screen:

```
                                    ┌────┐
                                    │ 📋 │ ← Logs (always visible)
                                    └────┘
                                    ┌────┐
                                    │ ⬆️ │ ← Scroll to Top (appears when scrolled down)
                                    └────┘
                                    ┌────┐
                                    │ ⬇️ │ ← Scroll to Bottom (appears when not at bottom)
                                    └────┘
```

---

## 📋 **1. Logs Viewer Button**

### What It Does:
Opens a modal to view all migration logs from your script execution.

### Appearance:
- **Color:** Purple gradient
- **Icon:** 📋
- **Always visible:** Yes
- **Hover effect:** Purple glow

### How to Use:

1. **Click the 📋 button** in the bottom-right corner
2. **Modal opens** showing the Logs interface
3. **Select a log file** from the dropdown menu
4. **View the contents** in the scrollable viewer
5. **Download** the log if needed

### Log File Types:

The viewer shows logs from three directories:

**Migration Logs** (`migration_logs/`)
- Main migration execution logs
- Filename format: `migration_YYYYMMDD_HHMMSS.log`

**Rollback Logs** (`rollback_logs/`)
- Rollback operation logs
- Filename format: `rollback_data_YYYYMMDD_HHMMSS.json`

**State Logs** (`state_logs/`)
- Migration state snapshots
- Filename format: `migration_state_YYYYMMDD_HHMMSS.json`

### Log Viewer Features:

✅ **Color-coded log levels:**
- 🔴 `[ERROR]` - Red text
- ⚠️ `[WARN]` - Yellow/orange text
- ✅ `[SUCCESS]` - Green text
- ℹ️ `[INFO]` - Purple text
- ⚪ Other - Default text

✅ **Monospace font** (JetBrains Mono) for better readability

✅ **Automatic sorting** - Newest logs appear first

✅ **File size display** - See log file sizes in KB

✅ **Download button** - Download any log file

✅ **Refresh button** - Reload the log list

---

## ⬆️ **2. Scroll to Top Button**

### What It Does:
Instantly scrolls to the top of the page with smooth animation.

### Appearance:
- **Color:** Green/teal gradient
- **Icon:** ⬆️
- **Visibility:** Appears when you scroll down more than 300px
- **Hover effect:** Green glow

### How to Use:
1. Scroll down the page
2. Button appears automatically
3. Click to smoothly scroll to the top
4. Button fades away when near the top

### Perfect For:
- Quickly returning to the header
- Accessing the Load Configuration button
- Checking the branch number input
- Viewing the theme toggle

---

## ⬇️ **3. Scroll to Bottom Button**

### What It Does:
Instantly scrolls to the bottom of the page with smooth animation.

### Appearance:
- **Color:** Orange/amber gradient
- **Icon:** ⬇️
- **Visibility:** Appears when you're more than 300px from the bottom
- **Hover effect:** Orange glow

### How to Use:
1. Be anywhere except the very bottom
2. Button appears automatically
3. Click to smoothly scroll to the bottom
4. Button fades away when at the bottom

### Perfect For:
- Checking the latest logs
- Viewing recent console output
- Accessing bottom panel content
- Quick navigation to the end of long pages

---

## 🎨 Button Animations

### Appearance Animation:
```
Scale from 0 → 1
Opacity 0% → 100%
Duration: 300ms
Easing: ease
```

### Hover Animation:
```
Scale: 1.0 → 1.1
Shadow: Increases
Glow: Appears
Duration: 300ms
```

### Click Animation:
```
Scale: 1.0 → 0.95 → 1.0
Feedback: Immediate
```

---

## 📊 Logs Modal Interface

### Top Toolbar:
```
┌─────────────────────────────────────────────────────────┐
│ [Select a log file... ▼]  [🔄 Refresh]  [⬇️ Download]  │
└─────────────────────────────────────────────────────────┘
```

### Content Area:
```
┌─────────────────────────────────────────────────────────┐
│ 2024-02-16 14:30:45 [INFO] Starting migration          │
│ 2024-02-16 14:30:46 [INFO] Loading configuration       │
│ 2024-02-16 14:30:47 [SUCCESS] Config loaded            │
│ 2024-02-16 14:30:48 [ERROR] Failed to connect          │
│ 2024-02-16 14:30:49 [WARN] Retrying in 5 seconds       │
│ ...                                                      │
│ [Scrollable content]                                     │
└─────────────────────────────────────────────────────────┘
```

---

## 🎯 Usage Scenarios

### Scenario 1: Checking Migration Progress

1. Run your migration
2. Click **📋 Logs** button
3. Select the latest `migration_*.log` file
4. Watch real-time progress
5. Check for any errors or warnings

### Scenario 2: Troubleshooting Errors

1. Migration fails
2. Click **📋 Logs** button
3. Select the relevant log file
4. Search for `[ERROR]` entries (shown in red)
5. Download log for detailed analysis

### Scenario 3: Quick Navigation

1. Working on Full Migration panel (top)
2. Need to check Bulk Operations (bottom)
3. Click **⬇️** to scroll to bottom instantly
4. Work on Bulk Operations
5. Click **⬆️** to return to top

---

## 🔧 Technical Details

### Button Visibility Logic:

**Logs Button (📋):**
```javascript
Always visible (show immediately on page load)
```

**Scroll to Top (⬆️):**
```javascript
if (scrollTop > 300px) {
    show button
} else {
    hide button
}
```

**Scroll to Bottom (⬇️):**
```javascript
if (distanceFromBottom > 300px) {
    show button
} else {
    hide button
}
```

### Scroll Behavior:
```javascript
window.scrollTo({
    top: targetPosition,
    behavior: 'smooth'  // Smooth animation
});
```

---

## 📁 API Endpoints

### List All Logs:
```
GET /api/logs

Response:
{
  "success": true,
  "logs": [
    {
      "name": "migration_20240216_143045.log",
      "path": "migration_logs/migration_20240216_143045.log",
      "size_kb": 45.67,
      "timestamp": "2024-02-16T14:30:45",
      "date": "2024-02-16 14:30:45",
      "type": "migration_logs"
    }
  ],
  "count": 15
}
```

### Get Log Content:
```
GET /api/logs/{log_path}

Response:
{
  "success": true,
  "content": "2024-02-16 14:30:45 [INFO] Starting...",
  "path": "migration_logs/migration_20240216_143045.log"
}
```

---

## 🎨 Theme Support

Both dark and light themes are fully supported:

### Dark Theme:
- Buttons: Vibrant gradients with strong glows
- Logs background: Dark gray (#0F1419)
- Text: Light colors for contrast

### Light Theme:
- Buttons: Same vibrant gradients
- Logs background: Light gray (#FAFBFC)
- Text: Dark colors for readability

---

## 💡 Pro Tips

### Tip 1: Quick Log Access
Keep the logs modal open while running migrations to watch progress in real-time. Just refresh the log list periodically.

### Tip 2: Keyboard + Mouse
Use scroll buttons for quick jumps, then use keyboard (Page Up/Down) for fine-tuning position.

### Tip 3: Download for Analysis
Download logs to your local machine for:
- Sharing with team members
- Long-term archival
- Offline analysis
- Importing into log analysis tools

### Tip 4: Color Scanning
Quickly scan logs by color:
- Red errors stand out immediately
- Yellow warnings catch your attention
- Green successes confirm progress

### Tip 5: Log File Naming
Log filenames include timestamps:
- `migration_20240216_143045.log`
- Year-Month-Day_Hour-Minute-Second
- Easy to identify when a migration ran

---

## 📊 Button States Summary

| Button | Trigger | Action | Color |
|--------|---------|--------|-------|
| 📋 Logs | Always | Opens logs modal | Purple |
| ⬆️ Top | Scroll > 300px down | Scrolls to top | Green |
| ⬇️ Bottom | Scroll > 300px from bottom | Scrolls to bottom | Orange |

---

## 🔍 Troubleshooting

### Buttons Not Appearing?

**Check 1:** Scroll position
- Top/Bottom buttons only appear when needed
- Try scrolling to trigger them

**Check 2:** JavaScript enabled
- Ensure browser JavaScript is enabled
- Check browser console for errors

**Check 3:** Screen size
- Buttons are positioned bottom-right
- May be off-screen on very small displays

### Logs Not Loading?

**Check 1:** Log files exist
- Ensure migration script has been run
- Check `migration_logs/` directory

**Check 2:** Backend running
- Ensure Flask server is running
- Check terminal for errors

**Check 3:** Permissions
- Ensure read permissions on log directories
- Check file access rights

---

## ✅ Complete Feature List

1. ✅ **Logs Viewer**
   - View all migration logs
   - Color-coded log levels
   - Download functionality
   - Refresh capability
   - Multiple log directories

2. ✅ **Scroll to Top**
   - Smooth animation
   - Auto-show/hide
   - Green gradient design
   - Hover effects

3. ✅ **Scroll to Bottom**
   - Smooth animation
   - Auto-show/hide
   - Orange gradient design
   - Hover effects

4. ✅ **Theme Support**
   - Works in dark theme
   - Works in light theme
   - Consistent appearance

5. ✅ **Responsive Design**
   - Adapts to screen size
   - Touch-friendly buttons
   - Mobile compatible

---

## 🎉 Summary

Three powerful floating action buttons enhance your GitLab Migration Tool:

- **📋 Logs** - Instant access to all migration logs
- **⬆️ Top** - Quick return to the top of the page
- **⬇️ Bottom** - Fast scroll to the bottom

**All buttons feature:**
- Beautiful gradient designs
- Smooth animations
- Smart visibility logic
- Theme support
- Professional appearance

**Navigate faster, debug easier, work smarter!** 🚀
