@echo off
REM Manual Installation Script for Artifactory Environments (Windows)
REM This script installs packages one-by-one with detailed error handling

echo ==========================================
echo GitLab Migration Tool - Manual Setup
echo ==========================================
echo.
echo This script will help you install dependencies in a corporate environment.
echo.

REM Check Python
echo Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo [91mPython 3 not found. Please install Python 3.8 or higher.[0m
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('python --version') do set PYTHON_VERSION=%%i
echo [92mPython found: %PYTHON_VERSION%[0m
echo.

REM Check pip
echo Checking pip installation...
pip --version >nul 2>&1
if errorlevel 1 (
    echo [91mpip not found. Please install pip.[0m
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('pip --version') do set PIP_VERSION=%%i
echo [92mpip found: %PIP_VERSION%[0m
echo.

REM Create virtual environment if it doesn't exist
if not exist venv (
    echo Creating virtual environment...
    python -m venv venv
    echo [92mVirtual environment created[0m
) else (
    echo [92mVirtual environment already exists[0m
)
echo.

REM Activate virtual environment
echo Activating virtual environment...
call venv\Scripts\activate.bat
echo [92mVirtual environment activated[0m
echo.

REM Check pip configuration
echo Checking pip configuration...
pip config list
echo.

REM Install packages
echo ==========================================
echo Installing Dependencies
echo ==========================================
echo.

REM Install Flask
echo Installing Flask 3.0.0...
pip install Flask==3.0.0 >nul 2>&1
if errorlevel 1 (
    echo    Retrying with increased timeout...
    pip install --timeout 120 Flask==3.0.0 >nul 2>&1
    if errorlevel 1 (
        echo    Retrying without SSL verification...
        pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org Flask==3.0.0 >nul 2>&1
        if errorlevel 1 (
            echo [91mFailed to install Flask[0m
            echo.
            echo Please install manually using your Artifactory URL:
            echo    pip install Flask==3.0.0 --index-url https://YOUR-ARTIFACTORY-URL/... --trusted-host YOUR-ARTIFACTORY
            set FLASK_FAILED=1
        ) else (
            echo [92mFlask installed successfully[0m
        )
    ) else (
        echo [92mFlask installed successfully[0m
    )
) else (
    echo [92mFlask installed successfully[0m
)
echo.

REM Install flask-cors
echo Installing flask-cors 4.0.0...
pip install flask-cors==4.0.0 >nul 2>&1
if errorlevel 1 (
    echo    Retrying with increased timeout...
    pip install --timeout 120 flask-cors==4.0.0 >nul 2>&1
    if errorlevel 1 (
        echo    Retrying without SSL verification...
        pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org flask-cors==4.0.0 >nul 2>&1
        if errorlevel 1 (
            echo [91mFailed to install flask-cors[0m
            echo.
            echo Please install manually using your Artifactory URL:
            echo    pip install flask-cors==4.0.0 --index-url https://YOUR-ARTIFACTORY-URL/... --trusted-host YOUR-ARTIFACTORY
            set CORS_FAILED=1
        ) else (
            echo [92mflask-cors installed successfully[0m
        )
    ) else (
        echo [92mflask-cors installed successfully[0m
    )
) else (
    echo [92mflask-cors installed successfully[0m
)
echo.

echo ==========================================
echo Installation Summary
echo ==========================================

if defined FLASK_FAILED goto FAILED
if defined CORS_FAILED goto FAILED

echo [92mAll dependencies installed successfully![0m
echo.
echo You can now run the application:
echo    python app.py
echo.
echo Or simply:
echo    run.bat
pause
exit /b 0

:FAILED
echo [93mSome dependencies failed to install.[0m
echo.
echo Please check ARTIFACTORY_SETUP.md for detailed instructions.
echo.
echo You may need to:
echo   1. Configure pip to use your Artifactory
echo   2. Contact your DevOps team for the correct Artifactory URL
echo   3. Download packages manually from Artifactory web interface
pause
exit /b 1
