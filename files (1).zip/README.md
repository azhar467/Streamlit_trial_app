# GitLab Migration Tool - Web UI 🚀

A stress-free web interface for migrating GitLab projects from Java 11 to Java 17.

## Features ✨

- **Beautiful Web Interface** - Modern, dark-themed UI with real-time updates
- **Project Selection** - Easy search and multi-select for projects
- **Live Progress** - Real-time progress bars and log streaming
- **Preview Changes** - See what will be modified before committing
- **Auto-commit** - Optional automatic commits for streamlined workflow
- **Safe Operations** - Preview before apply, with rollback support

## What This Tool Does

This migration tool automates the process of updating GitLab projects from Java 11 to Java 17 by:

1. **POM Updates** - Changes Java version from 11 to 17 in `pom.xml`
2. **CI/CD Updates** - Removes image references from `.gitlab-ci.yml`
3. **ElasticBeanstalk Updates** - Updates platform to Corretto 17 in `.elasticbeanstalk/config.yml`

## Quick Start 🏃

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure Environment

Create a `.env` file in the project root:

```bash
cp .env.example .env
```

Edit `.env` with your details:

```env
GITLAB_TOKEN=your_gitlab_personal_access_token
BASE_URL=https://gitlab.example.com

# Add your projects
PROJECT_101=user-authentication-service
PROJECT_102=payment-gateway-api
PROJECT_103=order-processing-service
```

**Getting a GitLab Token:**
1. Go to GitLab → Settings → Access Tokens
2. Create a token with `api`, `read_repository`, and `write_repository` scopes
3. Copy the token to your `.env` file

### 3. Run the Application

```bash
python app.py
```

The server will start at `http://localhost:5000`

### 4. Open Your Browser

Navigate to `http://localhost:5000` and you'll see the migration dashboard!

## Usage Guide 📖

### Step-by-Step Migration

1. **Load Configuration**
   - Click "Load Config" button
   - The tool will validate your GitLab token and load all projects
   - Status badge will turn green when connected

2. **Select Projects**
   - Use the search box to filter projects
   - Click on projects to select/deselect
   - Or use "Select All" / "Deselect All" buttons

3. **Choose Files to Update**
   - Check which files you want to update:
     - ✅ pom.xml (Java version)
     - ✅ .gitlab-ci.yml (CI config)
     - ✅ EB config (ElasticBeanstalk)

4. **Preview Changes (Optional)**
   - Click "Preview Changes" to see what will be modified
   - Review the log output showing file changes

5. **Start Migration**
   - Toggle "Auto-commit changes" if you want automatic commits
   - Click "Start Migration"
   - Watch real-time progress and logs

6. **Monitor Progress**
   - Progress bar shows overall completion
   - Live logs stream in real-time
   - Success/error indicators for each project

## Interface Overview 🎨

### Dashboard Stats
- **Total Projects** - All projects loaded from config
- **Selected** - Number of projects selected for migration
- **Completed** - Successfully migrated projects

### Project Panel
- Search and filter projects
- Multi-select with checkboxes
- Shows project ID and name

### File Updates Panel
- Select which files to update
- Auto-commit toggle
- Preview and Start buttons

### Progress Panel
- Real-time progress bar
- Live log streaming
- Color-coded log levels (INFO, SUCCESS, WARN, ERROR)

## Configuration Options ⚙️

### Environment Variables (.env)

```env
# Required
GITLAB_TOKEN=your_token        # GitLab personal access token
BASE_URL=https://gitlab.com    # Your GitLab instance URL

# Projects (add as many as needed)
PROJECT_101=project-name-1
PROJECT_102=project-name-2
PROJECT_103=project-name-3
```

### Migration Settings (in migration_backend.py)

```python
JIRA_ID = "1293"
UPGRADE_TYPE = "java17-migration"
FEATURE_BRANCH = f"task-{JIRA_ID}-{UPGRADE_TYPE}"
SOURCE_BRANCH = "develop"
MR_TITLE = f"TASK-{JIRA_ID}: java migration"
TARGET_PARENT_VERSION = "1.8.3"
NEW_DEFAULT_PLATFORM = "arn:aws:elasticbeanstalk:us-east-1::platform/Corretto 17 running on 64bit Amazon Linux 2/3.10.3"
```

## File Structure 📁

```
migration-tool/
├── app.py                    # Flask web application
├── migration_backend.py      # Migration logic (adapted from original script)
├── migration.py             # Original CLI script (backup)
├── templates/
│   └── index.html           # Web UI template
├── requirements.txt         # Python dependencies
├── .env                     # Your configuration (create this)
├── .env.example            # Example configuration
├── migration_logs/         # Migration logs (auto-created)
├── rollback_logs/          # Rollback data (auto-created)
└── state_logs/            # State snapshots (auto-created)
```

## Features in Detail 🔍

### Real-Time Log Streaming
- Uses Server-Sent Events (SSE) for live updates
- Color-coded log levels
- Auto-scrolls to latest messages

### Project Search
- Fuzzy search by project name or ID
- Instant filtering
- Maintains selection state

### Progress Tracking
- Overall progress percentage
- Current project indicator
- Visual progress bar with animation

### Safe Operations
- Preview changes before applying
- Optional auto-commit mode
- State saving for resume capability

## Troubleshooting 🔧

### "Not Connected" Status
- Check your `.env` file has correct GITLAB_TOKEN
- Verify BASE_URL is accessible
- Ensure token has required permissions

### No Projects Showing
- Make sure projects are defined in `.env` as PROJECT_XXX
- Click "Load Config" to refresh
- Check logs for any errors

### Migration Fails
- Check GitLab permissions (need Developer/Maintainer role)
- Verify branch doesn't already exist
- Review logs for specific error messages

### Port Already in Use
```bash
# Change port in app.py (last line)
app.run(debug=True, host='0.0.0.0', port=5001)
```

## API Endpoints 🔌

For advanced users or custom integrations:

- `GET /` - Web interface
- `POST /api/config/load` - Load configuration
- `GET /api/projects` - Get project list
- `POST /api/migration/preview` - Preview changes
- `POST /api/migration/start` - Start migration
- `GET /api/migration/status` - Get migration status
- `GET /api/logs/stream` - Stream logs (SSE)

## Comparison: CLI vs Web UI

### Original CLI Script
- ✅ Full-featured
- ✅ Scriptable
- ❌ Complex command-line interface
- ❌ No visual feedback
- ❌ Manual project selection

### New Web UI
- ✅ Visual, stress-free interface
- ✅ Real-time progress
- ✅ Easy project selection
- ✅ Live log streaming
- ✅ Preview changes
- ✅ Works on any device with browser

## Security Notes 🔒

- Keep your `.env` file secure (never commit it!)
- Use GitLab tokens with minimal required permissions
- Tokens are never logged or displayed in UI
- All API calls use HTTPS (if BASE_URL uses HTTPS)

## Tips for Best Experience 💡

1. **Start Small** - Test with 1-2 projects first
2. **Use Preview** - Always preview before migrating
3. **Check Logs** - Monitor logs during migration
4. **Auto-commit Off** - For first time, leave auto-commit off to review
5. **Save State** - Migration saves state, so you can resume if interrupted

## Support & Development

### Need Help?
- Check logs in the web interface
- Review migration_logs/ directory for detailed logs
- Ensure GitLab permissions are correct

### Want to Modify?
- Edit `migration_backend.py` to change migration logic
- Modify `templates/index.html` for UI changes
- Update `app.py` for API changes

## What's Next?

Planned features:
- [ ] Rollback from web UI
- [ ] Bulk MR creation
- [ ] Deploy-only mode
- [ ] Multi-user support
- [ ] Migration templates
- [ ] Export reports

---

Enjoy your stress-free migration! 🎉
