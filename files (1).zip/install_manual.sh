#!/bin/bash
# Manual Installation Script for Artifactory Environments
# This script installs packages one-by-one with detailed error handling

echo "=========================================="
echo "GitLab Migration Tool - Manual Setup"
echo "=========================================="
echo ""
echo "This script will help you install dependencies in a corporate environment."
echo ""

# Function to install package
install_package() {
    local package=$1
    local version=$2
    
    echo "Installing $package $version..."
    
    # Try multiple methods
    # Method 1: Standard pip
    pip install "$package==$version" 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "✅ $package installed successfully"
        return 0
    fi
    
    # Method 2: With increased timeout
    echo "   Retrying with increased timeout..."
    pip install --timeout 120 "$package==$version" 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "✅ $package installed successfully"
        return 0
    fi
    
    # Method 3: Without SSL verification (if in corporate env)
    echo "   Retrying without SSL verification..."
    pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org "$package==$version" 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "✅ $package installed successfully"
        return 0
    fi
    
    echo "❌ Failed to install $package"
    echo ""
    echo "Please install manually using your Artifactory URL:"
    echo "   pip install $package==$version --index-url https://YOUR-ARTIFACTORY-URL/... --trusted-host YOUR-ARTIFACTORY"
    echo ""
    return 1
}

# Check Python
echo "Checking Python installation..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3.8 or higher."
    exit 1
fi
echo "✅ Python found: $(python3 --version)"
echo ""

# Check pip
echo "Checking pip installation..."
if ! command -v pip &> /dev/null && ! command -v pip3 &> /dev/null; then
    echo "❌ pip not found. Please install pip."
    exit 1
fi
echo "✅ pip found: $(pip --version 2>/dev/null || pip3 --version)"
echo ""

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    echo "✅ Virtual environment created"
else
    echo "✅ Virtual environment already exists"
fi
echo ""

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate
echo "✅ Virtual environment activated"
echo ""

# Check pip configuration
echo "Checking pip configuration..."
pip config list
echo ""

# Install packages
echo "=========================================="
echo "Installing Dependencies"
echo "=========================================="
echo ""

# Install Flask
install_package "Flask" "3.0.0"
flask_status=$?

# Install flask-cors
install_package "flask-cors" "4.0.0"
cors_status=$?

echo ""
echo "=========================================="
echo "Installation Summary"
echo "=========================================="

if [ $flask_status -eq 0 ] && [ $cors_status -eq 0 ]; then
    echo "✅ All dependencies installed successfully!"
    echo ""
    echo "You can now run the application:"
    echo "   python app.py"
    echo ""
    echo "Or simply:"
    echo "   ./run.sh"
else
    echo "⚠️  Some dependencies failed to install."
    echo ""
    echo "Please check ARTIFACTORY_SETUP.md for detailed instructions."
    echo ""
    echo "You may need to:"
    echo "  1. Configure pip to use your Artifactory"
    echo "  2. Contact your DevOps team for the correct Artifactory URL"
    echo "  3. Download packages manually from Artifactory web interface"
    exit 1
fi
