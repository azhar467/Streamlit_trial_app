#!/bin/bash
# Quick Artifactory Installation
# Usage: ./install_artifactory.sh <ARTIFACTORY_URL>
# Example: ./install_artifactory.sh https://artifactory.mycompany.com

if [ -z "$1" ]; then
    echo "=========================================="
    echo "Quick Artifactory Installation"
    echo "=========================================="
    echo ""
    echo "Usage: $0 <ARTIFACTORY_URL>"
    echo ""
    echo "Example:"
    echo "  $0 https://artifactory.mycompany.com"
    echo ""
    echo "Or set your Artifactory URL when prompted..."
    echo ""
    read -p "Enter your Artifactory URL: " ARTIFACTORY_URL
else
    ARTIFACTORY_URL="$1"
fi

# Remove trailing slash if present
ARTIFACTORY_URL="${ARTIFACTORY_URL%/}"

echo ""
echo "Using Artifactory: $ARTIFACTORY_URL"
echo ""

# Extract hostname for trusted-host
ARTIFACTORY_HOST=$(echo "$ARTIFACTORY_URL" | sed -E 's|https?://([^/]+).*|\1|')

echo "Installing Flask from Artifactory..."
pip install Flask==3.0.0 \
    --index-url "$ARTIFACTORY_URL/artifactory/api/pypi/pypi-virtual/simple" \
    --trusted-host "$ARTIFACTORY_HOST"

if [ $? -ne 0 ]; then
    echo "Failed with pypi-virtual, trying pypi..."
    pip install Flask==3.0.0 \
        --index-url "$ARTIFACTORY_URL/artifactory/api/pypi/pypi/simple" \
        --trusted-host "$ARTIFACTORY_HOST"
fi

echo ""
echo "Installing flask-cors from Artifactory..."
pip install flask-cors==4.0.0 \
    --index-url "$ARTIFACTORY_URL/artifactory/api/pypi/pypi-virtual/simple" \
    --trusted-host "$ARTIFACTORY_HOST"

if [ $? -ne 0 ]; then
    echo "Failed with pypi-virtual, trying pypi..."
    pip install flask-cors==4.0.0 \
        --index-url "$ARTIFACTORY_URL/artifactory/api/pypi/pypi/simple" \
        --trusted-host "$ARTIFACTORY_HOST"
fi

echo ""
echo "=========================================="
echo "Installation complete!"
echo "=========================================="
echo ""
echo "To make this permanent, create ~/.pip/pip.conf with:"
echo ""
echo "[global]"
echo "index-url = $ARTIFACTORY_URL/artifactory/api/pypi/pypi-virtual/simple"
echo "trusted-host = $ARTIFACTORY_HOST"
echo ""
