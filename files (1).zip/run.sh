#!/bin/bash

echo "=========================================="
echo "GitLab Migration Tool - Web UI"
echo "=========================================="
echo ""

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "⚠️  .env file not found!"
    echo ""
    echo "Creating .env from example..."
    cp .env.example .env
    echo ""
    echo "✅ Created .env file"
    echo "📝 Please edit .env with your GitLab token and projects"
    echo ""
    echo "Then run this script again!"
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
    echo "✅ Virtual environment created"
    echo ""
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "📦 Installing dependencies..."

# Check if we should use Artifactory
if [ -f "pip.conf" ]; then
    echo "   Using pip.conf configuration (Artifactory)"
    pip install --config-settings pip.conf -r requirements.txt
elif [ -f "$HOME/.pip/pip.conf" ]; then
    echo "   Using ~/.pip/pip.conf configuration (Artifactory)"
    pip install -r requirements.txt
else
    echo "   Using default PyPI"
    pip install -r requirements.txt
fi

# Alternative: Install directly if network issues
if [ $? -ne 0 ]; then
    echo ""
    echo "⚠️  Installation failed. Trying alternative method..."
    echo "   Installing Flask and flask-cors separately..."
    pip install Flask==3.0.0
    pip install flask-cors==4.0.0
fi

echo ""
echo "=========================================="
echo "🚀 Starting Migration Tool..."
echo "=========================================="
echo ""
echo "Open your browser to: http://localhost:5000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

# Run the application
python app.py
