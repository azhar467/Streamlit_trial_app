# 🚨 ARTIFACTORY USERS - START HERE! 🚨

## You're Getting "Protocol Broken" Error?

You're in a corporate environment using Artifactory. Here's how to fix it:

## ⚡ FASTEST FIX (1 minute)

Run this command with YOUR Artifactory URL:

**Linux/Mac:**
```bash
./install_artifactory.sh https://artifactory.yourcompany.com
```

**Windows:**
```cmd
install_artifactory.bat https://artifactory.yourcompany.com
```

Don't know your Artifactory URL? Ask your DevOps team or check existing Python projects.

---

## 🔧 THREE WAYS TO FIX (Pick One)

### Option 1: Quick Install Script (Recommended)
Use the Artifactory installer above. It tries multiple repository paths automatically.

### Option 2: Manual One-Time Install
```bash
pip install Flask==3.0.0 \
  --index-url https://YOUR-ARTIFACTORY/artifactory/api/pypi/pypi-virtual/simple \
  --trusted-host YOUR-ARTIFACTORY-HOST

pip install flask-cors==4.0.0 \
  --index-url https://YOUR-ARTIFACTORY/artifactory/api/pypi/pypi-virtual/simple \
  --trusted-host YOUR-ARTIFACTORY-HOST
```

### Option 3: Configure pip Permanently (Best for Multiple Projects)

**Create pip configuration:**

Linux/Mac:
```bash
mkdir -p ~/.pip
cat > ~/.pip/pip.conf << EOF
[global]
index-url = https://YOUR-ARTIFACTORY/artifactory/api/pypi/pypi-virtual/simple
trusted-host = YOUR-ARTIFACTORY-HOST
timeout = 120
EOF
```

Windows:
```cmd
mkdir %APPDATA%\pip
echo [global] > %APPDATA%\pip\pip.ini
echo index-url = https://YOUR-ARTIFACTORY/artifactory/api/pypi/pypi-virtual/simple >> %APPDATA%\pip\pip.ini
echo trusted-host = YOUR-ARTIFACTORY-HOST >> %APPDATA%\pip\pip.ini
```

Then just run normal pip commands!

---

## 🆘 Still Not Working?

1. **Check the repository path** - Try these alternatives:
   - `/artifactory/api/pypi/pypi-virtual/simple`
   - `/artifactory/api/pypi/pypi/simple`
   - `/artifactory/api/pypi/pypi-local/simple`

2. **Contact your DevOps team** and ask:
   - "What's our Artifactory URL for Python packages?"
   - "Do we have Flask 3.0.0 available?"
   - "What's the correct pypi repository path?"

3. **Download manually** from Artifactory web UI:
   - Search for "Flask" and "flask-cors"
   - Download the `.whl` files
   - Install: `pip install Flask-3.0.0-py3-none-any.whl`

---

## 📚 Detailed Documentation

For complete Artifactory setup guide, see: **ARTIFACTORY_SETUP.md**

---

## ✅ After Installation

Once Flask and flask-cors are installed, run:
```bash
python app.py
```

Then open: **http://localhost:5000**

---

Need help? Check **ARTIFACTORY_SETUP.md** for detailed troubleshooting!
