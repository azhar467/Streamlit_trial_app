"""
GitLab Migration Tool - Web UI
A stress-free web interface for managing GitLab project migrations
"""

from flask import Flask, render_template, request, jsonify, Response
from flask_cors import CORS
import json
import threading
import queue
import time
import os
from datetime import datetime
from pathlib import Path

# Import migration functions
import migration_backend

app = Flask(__name__)
CORS(app)

# Global state
migration_state = {
    'running': False,
    'progress': 0,
    'current_project': None,
    'logs': [],
    'results': [],
    'projects': {},
    'config_loaded': False
}

# Log queue for real-time streaming
log_queue = queue.Queue()

def add_log(message, level='INFO'):
    """Add a log message to the queue"""
    timestamp = datetime.now().strftime('%H:%M:%S')
    log_entry = {
        'timestamp': timestamp,
        'level': level,
        'message': message
    }
    log_queue.put(log_entry)
    migration_state['logs'].append(log_entry)

@app.route('/')
def index():
    """Main dashboard"""
    return render_template('index.html')

@app.route('/api/config/load', methods=['POST'])
def load_config():
    """Load configuration and projects from .env file"""
    try:
        # Load environment variables and projects
        config = migration_backend.load_configuration()
        
        migration_state['config_loaded'] = True
        migration_state['projects'] = config['projects']
        
        add_log(f"Configuration loaded successfully", 'SUCCESS')
        add_log(f"Found {len(config['projects'])} projects", 'INFO')
        
        return jsonify({
            'success': True,
            'projects': config['projects'],
            'base_url': config.get('base_url', ''),
            'token_valid': config.get('token_valid', False)
        })
    except Exception as e:
        add_log(f"Error loading configuration: {str(e)}", 'ERROR')
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/api/projects')
def get_projects():
    """Get list of all projects"""
    return jsonify({
        'projects': migration_state['projects']
    })

@app.route('/api/migration/preview', methods=['POST'])
def preview_changes():
    """Preview changes for selected projects"""
    try:
        data = request.json
        project_ids = data.get('project_ids', [])
        file_types = data.get('file_types', [])
        
        add_log(f"Previewing changes for {len(project_ids)} projects", 'INFO')
        
        # Get previews from backend
        previews = migration_backend.preview_changes(project_ids, file_types)
        
        return jsonify({
            'success': True,
            'previews': previews
        })
    except Exception as e:
        add_log(f"Error previewing changes: {str(e)}", 'ERROR')
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/api/migration/start', methods=['POST'])
def start_migration():
    """Start the migration process"""
    if migration_state['running']:
        return jsonify({'success': False, 'error': 'Migration already running'}), 400
    
    try:
        data = request.json
        project_ids = data.get('project_ids', [])
        file_types = data.get('file_types', [])
        mode = data.get('mode', 'full')
        auto_commit = data.get('auto_commit', False)
        
        # Reset state
        migration_state['running'] = True
        migration_state['progress'] = 0
        migration_state['results'] = []
        migration_state['logs'] = []
        
        add_log(f"Starting migration for {len(project_ids)} projects", 'INFO')
        add_log(f"Mode: {mode}, File types: {', '.join(file_types)}", 'INFO')
        
        # Run migration in background thread
        thread = threading.Thread(
            target=run_migration,
            args=(project_ids, file_types, mode, auto_commit)
        )
        thread.daemon = True
        thread.start()
        
        return jsonify({'success': True, 'message': 'Migration started'})
    except Exception as e:
        migration_state['running'] = False
        add_log(f"Error starting migration: {str(e)}", 'ERROR')
        return jsonify({'success': False, 'error': str(e)}), 400

def run_migration(project_ids, file_types, mode, auto_commit):
    """Run migration in background thread"""
    try:
        total = len(project_ids)
        
        for idx, pid in enumerate(project_ids):
            project_name = migration_state['projects'].get(str(pid), f'Project {pid}')
            migration_state['current_project'] = {
                'id': pid,
                'name': project_name,
                'index': idx + 1,
                'total': total
            }
            
            add_log(f"Processing {project_name} ({idx + 1}/{total})", 'INFO')
            
            # Process project
            result = migration_backend.process_project_web(
                pid,
                file_types,
                mode,
                auto_commit,
                log_callback=add_log
            )
            
            migration_state['results'].append(result)
            migration_state['progress'] = int((idx + 1) / total * 100)
            
            if result['success']:
                add_log(f"✓ Completed {project_name}", 'SUCCESS')
            else:
                add_log(f"✗ Failed {project_name}: {result.get('error', 'Unknown error')}", 'ERROR')
        
        migration_state['running'] = False
        migration_state['current_project'] = None
        add_log("Migration completed", 'SUCCESS')
        
    except Exception as e:
        migration_state['running'] = False
        migration_state['current_project'] = None
        add_log(f"Migration failed: {str(e)}", 'ERROR')

@app.route('/api/migration/status')
def get_status():
    """Get current migration status"""
    return jsonify({
        'running': migration_state['running'],
        'progress': migration_state['progress'],
        'current_project': migration_state['current_project'],
        'results': migration_state['results']
    })

@app.route('/api/logs/stream')
def stream_logs():
    """Stream logs in real-time using Server-Sent Events"""
    def generate():
        # Send existing logs first
        for log in migration_state['logs'][-50:]:  # Last 50 logs
            yield f"data: {json.dumps(log)}\n\n"
        
        # Stream new logs
        while True:
            try:
                log = log_queue.get(timeout=1)
                yield f"data: {json.dumps(log)}\n\n"
            except queue.Empty:
                # Send heartbeat
                yield f": heartbeat\n\n"
    
    return Response(generate(), mimetype='text/event-stream')

@app.route('/api/rollback', methods=['POST'])
def rollback():
    """Rollback a migration"""
    try:
        data = request.json
        rollback_file = data.get('rollback_file')
        
        add_log(f"Starting rollback from {rollback_file}", 'WARN')
        
        result = migration_backend.perform_rollback_web(
            rollback_file,
            log_callback=add_log
        )
        
        if result['success']:
            add_log("Rollback completed successfully", 'SUCCESS')
            return jsonify({'success': True})
        else:
            add_log(f"Rollback failed: {result.get('error')}", 'ERROR')
            return jsonify({'success': False, 'error': result.get('error')}), 400
            
    except Exception as e:
        add_log(f"Rollback error: {str(e)}", 'ERROR')
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/api/rollback/files')
def get_rollback_files():
    """Get list of available rollback files"""
    try:
        rollback_dir = Path('rollback_logs')
        if rollback_dir.exists():
            files = [
                {
                    'name': f.name,
                    'path': str(f),
                    'size': f.stat().st_size,
                    'modified': datetime.fromtimestamp(f.stat().st_mtime).isoformat()
                }
                for f in rollback_dir.glob('rollback_data_*.json')
            ]
            files.sort(key=lambda x: x['modified'], reverse=True)
            return jsonify({'files': files})
        return jsonify({'files': []})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    print("=" * 70)
    print("GitLab Migration Tool - Web UI")
    print("=" * 70)
    print("\n🚀 Starting server at http://localhost:5000")
    print("\n📝 Make sure you have:")
    print("   1. .env file with your GitLab token and projects")
    print("   2. migration_backend.py in the same directory")
    print("\n" + "=" * 70 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
