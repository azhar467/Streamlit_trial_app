# 🔧 Debugging Improvements - Diff Preview Issue

## What I've Added to Help Debug

I've enhanced your GitLab Migration Tool with comprehensive debugging capabilities to help identify why pom.xml and elasticbeanstalk/config.yml diffs aren't showing.

---

## 🆕 New Debugging Features

### 1. **Backend Logging (Flask Terminal)**

**Added comprehensive console output:**

```python
[PREVIEW] Starting preview for project 123
[PREVIEW] Choices: ['1', '3']
[PREVIEW] Processing pom.xml...
[PREVIEW] Original pom.xml length: 2548 chars
[PREVIEW] Updated pom.xml length: 2548 chars
[PREVIEW] Content changed: False  ← KEY INDICATOR
[DEBUG] Generated diff with 0 characters
[PREVIEW] pom.xml unchanged, skipping
```

**What to look for:**
- `Content changed: False` = File doesn't need changes (already migrated)
- `Content changed: True` = Changes detected
- `Diff length: 0` = No differences found
- `Failed to fetch` = File doesn't exist

---

### 2. **Frontend Console Logging (Browser)**

**Added detailed JavaScript debugging:**

```javascript
[DEBUG] Preview result for my-service: {success: true, actions: Array(1)}
[DEBUG] File: pom.xml
[DEBUG] Diff length: 234
[DEBUG] Diff preview: @@ -15,7 +15,7 @@...
[DEBUG] Found hunk header: @@ -15,7 +15,7 @@
[DEBUG] Processed 12 lines, hasContent: true
```

**How to access:**
1. Press `F12` to open Developer Tools
2. Go to "Console" tab
3. Click "Preview" button
4. Watch the debug output

---

### 3. **Raw Diff Fallback Display**

**If diff parsing fails, you'll now see:**

```
⚠️ Diff Parsing Issue
No changes detected in standard format. Showing raw diff:

--- before
+++ after
@@ -15,3 +15,3 @@
 <properties>
-  <java.version>11</java.version>
+  <java.version>17</java.version>
```

This ensures you can **always see** if changes exist, even if the formatted display has issues.

---

## 🎯 How to Debug

### Quick 3-Step Process:

**Step 1: Check Flask Terminal**
```bash
# Look for these logs when you click Preview
[PREVIEW] Content changed: True/False
[DEBUG] Generated diff with X characters
```

**Step 2: Check Browser Console**
```
F12 → Console tab → Click Preview
Look for: [DEBUG] Diff length: X
```

**Step 3: Compare Results**
- Both show changes = Display issue
- Backend shows no changes = Files already correct
- Backend shows changes but frontend doesn't = Network/parsing issue

---

## 🔍 Most Likely Causes

### Cause 1: Files Already Migrated (Most Common!)

**Symptoms:**
```
Backend: "Content changed: False"
Backend: "pom.xml unchanged, skipping"
Frontend: No diff shown
```

**This is EXPECTED!** Your files are already correct. No changes needed = No diff to show.

**To Verify:**
```bash
# Check if pom.xml already has Java 17
grep -A 2 "java.version" pom.xml

# Should show either:
<java.version>11</java.version>  ← Needs migration
<java.version>17</java.version>  ← Already migrated ✓
```

---

### Cause 2: Missing Configuration

**Symptoms:**
```
Backend: "config.yml unchanged, skipping"
```

**Check:**
```bash
# Is NEW_DEFAULT_PLATFORM set in .env?
grep NEW_DEFAULT_PLATFORM .env
```

**Should see:**
```
NEW_DEFAULT_PLATFORM=arn:aws:elasticbeanstalk:...
```

**If missing:** Add it and restart Flask server.

---

### Cause 3: Regex Pattern Mismatch

**Symptoms:**
```
Backend: File fetched but "Content changed: False"
Your file has: <java.version> 11 </java.version>
Expected format: <java.version>11</java.version>
```

**The regex expects exact format:**
```xml
<java.version>11</java.version>
```

**Won't match:**
```xml
<java.version> 11 </java.version>  ← Extra spaces
<java.version>1.8</java.version>   ← Different version
```

---

## 📊 Interpreting the Logs

### Successful Diff Generation:

**Backend:**
```
✓ [PREVIEW] Content changed: True
✓ [DEBUG] Generated diff with 234 characters
✓ [DEBUG] Diff starts with: @@ -15,7 +15,7 @@
✓ [PREVIEW] Total actions generated: 1
```

**Frontend:**
```
✓ [DEBUG] Diff length: 234
✓ [DEBUG] Found hunk header: @@ -15,7 +15,7 @@
✓ [DEBUG] Processed 12 lines, hasContent: true
```

**Result:** Diff displays correctly ✅

---

### No Changes Detected:

**Backend:**
```
✗ [PREVIEW] Content changed: False
✗ [PREVIEW] pom.xml unchanged, skipping
✗ [PREVIEW] Total actions generated: 0
```

**Frontend:**
```
Toast: "No Changes" - No changes detected
```

**Result:** Files don't need migration (already correct) ✅

---

### Display Parsing Issue:

**Backend:**
```
✓ [DEBUG] Generated diff with 234 characters
✓ [DEBUG] Diff starts with: @@ -15,7 +15,7 @@
```

**Frontend:**
```
✗ [DEBUG] Processed 12 lines, hasContent: false
⚠️ Shows raw diff instead
```

**Result:** Changes exist but display needs fixing. Raw diff shown as fallback.

---

## 🛠️ Testing Commands

### Test 1: Verify Flask Is Logging

```bash
# In your Flask terminal, you should see:
python app.py

# Output should include:
[PREVIEW] Starting preview...
[DEBUG] Generated diff...
```

**If you don't see these:** The logging code didn't load. Restart Flask.

---

### Test 2: Check Browser Console

```javascript
// Open browser console (F12)
// Click Preview
// Should see output starting with [DEBUG]

// If not, refresh page and try again
```

---

### Test 3: Manually Check Files

```bash
# For pom.xml
cat your-project/pom.xml | grep -B 2 -A 2 "java.version"

# For config.yml  
cat your-project/.elasticbeanstalk/config.yml | grep "default_platform"
```

Compare with what the migration should produce.

---

## ✅ Resolution Steps

### If Backend Shows "Content changed: False"

**This is the root cause.** Your files don't need changes.

**Options:**
1. **Accept it:** Files are already correct (most common)
2. **Verify manually:** Check files yourself
3. **Adjust regex:** If file format is different, update backend patterns

---

### If Backend Shows Changes But Frontend Doesn't

**Network or parsing issue.**

**Steps:**
1. Check browser Network tab (F12 → Network)
2. Find the `/api/projects/{id}/preview` request
3. Check the response - does it contain the diff?
4. If yes: Frontend parsing issue (raw diff will show)
5. If no: Backend issue (check Flask logs)

---

### If Raw Diff Shows But Not Formatted

**This is a display issue, but changes are confirmed.**

**The raw diff proves changes exist!** The formatted view just needs adjustment.

**Action:** Use raw diff to verify changes are correct, proceed with migration.

---

## 📋 Complete Debug Workflow

```
1. Start Flask with logging:
   python app.py
   
2. Open browser with console:
   F12 → Console tab
   
3. Click "Preview" button

4. Check BOTH outputs:
   - Flask Terminal: [PREVIEW] logs
   - Browser Console: [DEBUG] logs
   
5. Compare findings:
   - Both show diffs? ✓ Working
   - Backend says no changes? ✓ Already migrated
   - Backend has diff, frontend doesn't? → Check network
   - Raw diff shows? ✓ Changes confirmed, display issue only
```

---

## 🎯 Expected Outcome

After following the debug workflow, you'll know **exactly** why diffs aren't showing:

**Most Common (90%):** Files already migrated, no changes needed ✓

**Configuration (8%):** Missing .env settings or wrong branch

**Display Issue (2%):** Backend generates diff but frontend can't parse (raw diff shows it)

---

## 📞 What to Share If Still Stuck

If after all debugging you still have issues, share:

1. **Flask terminal output** - Copy the `[PREVIEW]` and `[DEBUG]` lines
2. **Browser console output** - Copy the `[DEBUG]` lines  
3. **First 50 lines of your file** - Share the actual pom.xml/config.yml
4. **Your .env NEW_DEFAULT_PLATFORM** - (redact sensitive parts)

This will pinpoint the exact issue immediately!

---

## 🎉 Summary

You now have:
- ✅ Comprehensive backend logging
- ✅ Detailed frontend debugging  
- ✅ Raw diff fallback display
- ✅ Complete troubleshooting guide
- ✅ Clear diagnostic workflow

**Run the 3-step debug process above to identify the issue!** 🚀
