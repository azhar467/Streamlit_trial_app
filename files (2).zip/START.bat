@echo off
title GitLab Migration Tool Launcher
color 0B

echo.
echo ================================================
echo    GitLab Migration Tool
echo    Java 11 to Java 17 Migration
echo ================================================
echo.

REM Check Python installation
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found!
    echo Please install Python 3.9 or higher from python.org
    echo.
    pause
    exit /b 1
)

REM Check required files
if not exist "migration_script.py" (
    echo [ERROR] migration_script.py not found!
    echo Please copy your migration_script.py to this folder
    echo.
    pause
    exit /b 1
)

if not exist ".env" (
    echo [ERROR] .env file not found!
    echo Please copy your .env file to this folder
    echo.
    pause
    exit /b 1
)

REM Check and install dependencies
echo [STEP 1/3] Checking dependencies...
pip show flask >nul 2>&1
if errorlevel 1 (
    echo Installing Flask dependencies...
    pip install -q -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Failed to install dependencies
        pause
        exit /b 1
    )
    echo Dependencies installed successfully!
) else (
    echo Dependencies OK!
)

echo.
echo [STEP 2/3] Starting Flask server...
echo Server URL: http://localhost:5000
echo.

REM Start Flask server in background
start /B python app.py >nul 2>&1

REM Wait for server to start
echo [STEP 3/3] Waiting for server to start...
timeout /t 3 /nobreak >nul

REM Open browser
echo Opening browser...
start http://localhost:5000

echo.
echo ================================================
echo    Migration Tool is Running!
echo ================================================
echo.
echo The tool is now open in your browser.
echo.
echo To STOP the server: Close this window or press Ctrl+C
echo.
pause

REM Kill Flask when batch exits
taskkill /F /IM python.exe /FI "WINDOWTITLE eq GitLab*" >nul 2>&1
