# GitLab Migration Tool - Simple UI

## 🚀 Quick Start (3 Steps)

### Step 1: Setup Files

Copy these files to this folder:
```
simple_ui/
├── START.bat           ✅ (provided)
├── app.py              ✅ (provided)
├── index.html          ✅ (provided)
├── requirements.txt    ✅ (provided)
├── migration_script.py ⬅️ COPY YOUR FILE HERE
└── .env                ⬅️ COPY YOUR FILE HERE
```

### Step 2: Run

**Double-click `START.bat`**

That's it! The browser will open automatically.

### Step 3: Use the Tool

1. Click **"⚙️ Load Configuration"** button (top right)
2. Use the three panels:
   - **Left**: Full Migration (preview → commit → MR)
   - **Middle**: Bulk MR Creation
   - **Right**: Tag & Deploy

---

## 📋 Three-Panel Layout

### Left Panel: Full Migration
```
1. Select projects (checkboxes)
2. Select files to update (POM, CI, EB)
3. Click "Preview Changes" → See colored diffs
   • Green = Additions
   • Red = Deletions
4. Click "Commit" → Push to feature branch
5. Click "Create MR" → Create merge request
```

### Middle Panel: Bulk MR Creation
```
1. Select multiple projects (checkboxes)
2. Select reviewers (checkboxes)
3. Select assignees (checkboxes)
4. Click "Create MRs for Selected"
5. Watch progress in logs
```

### Right Panel: Tag & Deploy
```
1. Select ONE project (radio button)
2. Click "Load Tags"
3. Select tags to deploy (dev, test, performance)
   • Protected tags are disabled (🔒)
4. Click "Start Deployment"
5. Watch full deployment process:
   • Tag creation
   • Pipeline monitoring
   • eb-terminate
   • Deployment
```

---

## 🎨 Features

### ✅ Minimal Dependencies
- Only Flask and Flask-CORS
- No Socket.IO
- No external CSS/JS libraries
- Everything self-contained

### ✅ Colored Diff Viewer
- **Green** = Added lines
- **Red** = Removed lines
- **Blue** = File headers
- **Gray** = Context

### ✅ Real-time Progress
- Auto-refresh task status
- Live log updates
- Color-coded messages

### ✅ Three Workflows
1. **Full Migration**: Complete control, project by project
2. **Bulk MR**: Fast MR creation for many projects
3. **Tag & Deploy**: Full deployment automation

---

## 🔧 Configuration

Your `.env` file should contain:

```bash
BASE_URL=https://gitlab.example.com/api/v4
GITLAB_TOKEN=your_token_here

NEW_DEFAULT_PLATFORM=arn:aws:elasticbeanstalk:us-east-1::platform/Corretto 17 running on 64bit Amazon Linux 2/3.10.3

REVIEWER_USERNAMES=azhar.ahmed,ayush.goyal
ASSIGNEE_USERNAMES=john.doe

PROJECT_101=user-authentication-service
PROJECT_102=payment-gateway-api
PROJECT_103=notification-service
```

---

## 🎯 Usage Examples

### Example 1: Migrate 3 Projects
```
1. Double-click START.bat
2. Click "Load Configuration"
3. Left Panel:
   - Check 3 projects
   - Click "Preview Changes"
   - Review colored diffs
   - Click "Commit"
   - Click "Create MR"
Done!
```

### Example 2: Create 20 MRs at Once
```
1. Double-click START.bat
2. Click "Load Configuration"
3. Middle Panel:
   - Click "Select All Projects"
   - Check your reviewers
   - Click "Create MRs for Selected"
Done!
```

### Example 3: Deploy to Dev & Test
```
1. Double-click START.bat
2. Click "Load Configuration"
3. Right Panel:
   - Select a project
   - Click "Load Tags"
   - Check "dev" and "test"
   - Click "Start Deployment"
   - Watch logs for 15-30 minutes
Done!
```

---

## 🎨 Color Scheme

The UI uses a dark theme with vibrant colors:

- **Background**: Dark blue (#1a1a2e)
- **Headers**: Gradient blue
- **Primary**: Teal (#4ecca3)
- **Success**: Cyan (#00d9ff)
- **Danger**: Red (#e94560)
- **Added lines**: Green
- **Removed lines**: Red

---

## 🛠️ Troubleshooting

### Problem: "Python not found"
**Solution**: Install Python 3.9+ from python.org

### Problem: "migration_script.py not found"
**Solution**: Copy your existing migration_script.py to this folder

### Problem: ".env file not found"
**Solution**: Copy your .env file to this folder

### Problem: Browser doesn't open
**Solution**: Manually open http://localhost:5000

### Problem: "Load Configuration" button does nothing
**Solution**: 
- Check browser console (F12) for errors
- Verify Flask server is running in the batch window
- Verify .env file has projects

---

## 📁 What Each File Does

- **START.bat**: Launches everything (Python check → Install deps → Start Flask → Open browser)
- **app.py**: Minimal Flask backend (API only, no Socket.IO)
- **index.html**: Complete UI (three panels, all styling/JavaScript embedded)
- **requirements.txt**: Only 2 dependencies (Flask, Flask-CORS)
- **migration_script.py**: Your existing script (reused 100%)
- **.env**: Your existing config (reused 100%)

---

## 💡 Tips

1. **Start small**: Test with 1 project before bulk operations
2. **Keep window open**: Don't close the batch file window
3. **Watch colors**: Green = good, Red = error, Blue = info
4. **Use Select All**: For bulk operations, use the "Select All" checkbox
5. **Protected tags**: These are automatically disabled - you can't accidentally deploy to production

---

## 🚀 That's It!

Just **double-click START.bat** and you're ready to migrate! 

Everything is self-contained, minimal dependencies, and works out of the box.
