# 🔍 Troubleshooting Diff Preview Issues

## Issue: pom.xml and elasticbeanstalk/config.yml Not Showing Differences

This guide will help you diagnose why diffs aren't appearing for certain files.

---

## 📊 Step 1: Check Backend Logs

I've added comprehensive logging to help debug this issue. When you click "Preview," check your **Flask terminal/console** for detailed output.

### What to Look For:

```
[PREVIEW] Starting preview for project 123
[PREVIEW] Choices: ['1', '3']
[PREVIEW] Branch: develop

[PREVIEW] Processing pom.xml...
[PREVIEW] Original pom.xml length: 2548 chars
[PREVIEW] Updated pom.xml length: 2548 chars
[PREVIEW] Content changed: False  ← KEY: If False, no changes detected!

[DEBUG] Generated diff with 0 characters  ← Empty diff = no changes
```

### Key Indicators:

**1. Content Changed: False**
- This means the regex transformations didn't find anything to change
- Either the file already has Java 17, or the pattern doesn't match

**2. Diff length: 0 characters**
- No differences were found between old and new content
- File is unchanged

**3. Failed to fetch**
- The file doesn't exist in the repository
- Check the file path

---

## 🔍 Step 2: Check Browser Console

Open your browser's Developer Console (F12) and look for logs:

### Expected Output:

```
[DEBUG] Preview result for my-service: {success: true, actions: Array(2)}
[DEBUG] File: pom.xml
[DEBUG] Diff length: 1234
[DEBUG] Diff preview: @@ -15,7 +15,7 @@...
```

### Problem Indicators:

```
[DEBUG] File: pom.xml
[DEBUG] Diff length: 0  ← EMPTY!
[DEBUG] Diff preview: EMPTY  ← NO CONTENT!
```

---

## 🐛 Common Causes & Solutions

### Cause 1: Files Already Updated

**Symptom:** Backend logs show "Content changed: False"

**Reason:** The files already contain Java 17 or the correct configuration.

**Solution:**
1. Check if your project already migrated:
   ```bash
   # Check pom.xml
   cat pom.xml | grep -A 2 java.version
   
   # Should show:
   # <java.version>11</java.version>  ← Needs migration
   # OR
   # <java.version>17</java.version>  ← Already migrated
   ```

2. Check elasticbeanstalk config:
   ```bash
   cat .elasticbeanstalk/config.yml | grep default_platform
   
   # Should show current platform
   ```

**If already migrated:** This is expected behavior - no diff because no changes needed!

---

### Cause 2: Regex Pattern Not Matching

**Symptom:** Backend logs show file fetched but no changes detected

**Reason:** The file structure doesn't match the expected pattern.

**For pom.xml:**
The regex looks for:
```xml
<java.version>11</java.version>
<maven.compiler.source>11</maven.compiler.source>
```

**Common Variations That Won't Match:**
```xml
<!-- Extra spaces -->
<java.version> 11 </java.version>

<!-- Different version -->
<java.version>1.8</java.version>

<!-- Property reference -->
<java.version>${java.version}</java.version>
```

**Solution:** Check your actual pom.xml structure and adjust the backend regex if needed.

---

### Cause 3: Missing NEW_DEFAULT_PLATFORM

**Symptom:** elasticbeanstalk/config.yml shows no changes

**Check your .env file:**
```bash
grep NEW_DEFAULT_PLATFORM .env
```

**Expected:**
```
NEW_DEFAULT_PLATFORM=arn:aws:elasticbeanstalk:us-east-1::platform/Java 17 running on 64bit Amazon Linux 2/4.2.3
```

**If missing or empty:**
1. Add to your `.env` file
2. Restart Flask server
3. Try preview again

---

### Cause 4: Wrong Branch Selected

**Symptom:** Changes don't appear even though they should

**Reason:** Previewing wrong branch (e.g., develop vs feature branch)

**Solution:**
Currently hardcoded to `develop` branch. If you need a different branch, update the code:

```javascript
// In previewFullMigration() function
body: JSON.stringify({ choices, branch: 'your-branch-name' })
```

---

## 🔧 Step 3: Enable Raw Diff Display

The updated code now shows a **fallback raw diff** if parsing fails.

### What You'll See:

If the diff parser can't process the diff, you'll see:

```
⚠️ Diff Parsing Issue
No changes detected in standard format. Showing raw diff:

--- before
+++ after
@@ -15,3 +15,3 @@
 <properties>
-  <java.version>11</java.version>
+  <java.version>17</java.version>
 </properties>
```

This lets you see the actual diff even if the display has issues.

---

## 🧪 Step 4: Test with Known Changes

Create a test case to verify the diff display works:

### Test pom.xml:

1. Manually edit a test project's pom.xml
2. Change something obvious:
   ```xml
   <!-- Before -->
   <java.version>11</java.version>
   
   <!-- After -->
   <java.version>17</java.version>
   ```

3. Preview that project
4. You should see red/green diff

### If this works, the display is fine. The issue is with the specific files.

---

## 📋 Diagnostic Checklist

Run through this checklist:

```
□ Flask server is running
□ Browser console shows no JavaScript errors
□ Backend console shows [PREVIEW] logs
□ Backend logs show "Content changed: True"
□ Backend logs show diff length > 0
□ Browser console shows diff length > 0
□ Files actually need changes (not already migrated)
□ .env file has NEW_DEFAULT_PLATFORM set
□ Correct branch is being previewed
□ Regex patterns match your file structure
```

---

## 🛠️ Step 5: Manual Verification

### For pom.xml:

**Check if changes would apply:**

1. Open your pom.xml
2. Search for these patterns:
   ```xml
   <java.version>11</java.version>
   <maven.compiler.source>11</maven.compiler.source>
   <maven.compiler.target>11</maven.compiler.target>
   <maven.compiler.release>11</maven.compiler.release>
   ```

3. If found: Changes should be detected
4. If not found: File already correct or different structure

### For .elasticbeanstalk/config.yml:

**Check current platform:**

1. Open .elasticbeanstalk/config.yml
2. Find the `default_platform:` line
3. Compare with your NEW_DEFAULT_PLATFORM
4. If they match: No changes needed (expected)
5. If different: Should show diff

---

## 🎯 Quick Debug Commands

### Backend Terminal:

```bash
# Watch Flask logs in real-time
python app.py | grep -E "\[PREVIEW\]|\[DEBUG\]"

# Check if .env is loaded
python -c "from dotenv import load_dotenv; import os; load_dotenv(); print(os.getenv('NEW_DEFAULT_PLATFORM'))"
```

### Browser Console:

```javascript
// Check what the frontend received
// (Run after clicking Preview)
console.log(previewData);

// Check diff content
previewData[0].actions.forEach(a => {
    console.log(`File: ${a.file_path}`);
    console.log(`Diff length: ${a.diff.length}`);
    console.log(`Diff: ${a.diff.substring(0, 500)}`);
});
```

---

## 📊 Sample Debug Output

### Successful Case:

**Backend:**
```
[PREVIEW] Starting preview for project 123
[PREVIEW] Processing pom.xml...
[PREVIEW] Original pom.xml length: 2548 chars
[PREVIEW] Updated pom.xml length: 2550 chars
[PREVIEW] Content changed: True  ✓
[DEBUG] Generated diff with 234 characters  ✓
[DEBUG] Diff starts with: @@ -15,7 +15,7 @@  ✓
[PREVIEW] Total actions generated: 1  ✓
```

**Browser:**
```
[DEBUG] Preview result: {success: true, actions: Array(1)}
[DEBUG] File: pom.xml
[DEBUG] Diff length: 234  ✓
[DEBUG] Found hunk header: @@ -15,7 +15,7 @@  ✓
[DEBUG] Processed 12 lines, hasContent: true  ✓
```

### Failed Case (Already Migrated):

**Backend:**
```
[PREVIEW] Processing pom.xml...
[PREVIEW] Original pom.xml length: 2548 chars
[PREVIEW] Updated pom.xml length: 2548 chars
[PREVIEW] Content changed: False  ✗
[PREVIEW] pom.xml unchanged, skipping  ✗
[PREVIEW] Total actions generated: 0  ✗
```

**Result:** No diff to show (expected - file already correct!)

---

## 🔄 Next Steps

### If Files Are Already Migrated:
This is **expected behavior**. The preview only shows files that need changes. No diff = no changes needed = all good! ✓

### If Files Should Change But Don't:
1. Check backend logs for the exact reason
2. Verify regex patterns match your file structure
3. Ensure .env variables are set correctly
4. Check you're previewing the correct branch

### If You See Raw Diff But Not Formatted:
This is a parsing issue. The raw diff confirms changes exist, just display needs fixing. File an issue with the raw diff output for analysis.

---

## 💡 Pro Tips

**Tip 1:** Always check Flask terminal **first**  
The backend logs tell you exactly what's happening.

**Tip 2:** Test with .gitlab-ci.yml first  
It has the simplest transformation (just removes a line).  
If this shows a diff, the display works.

**Tip 3:** Run preview multiple times  
First run might have caching issues. Try 2-3 times.

**Tip 4:** Use raw diff as proof  
Even if formatted display fails, raw diff shows changes exist.

---

## ✅ Resolution Checklist

Before reporting an issue, confirm:

- [ ] Checked Flask terminal logs
- [ ] Checked browser console
- [ ] Verified files actually need changes
- [ ] Tested with .gitlab-ci.yml (simpler case)
- [ ] Restarted Flask server
- [ ] Cleared browser cache
- [ ] Checked .env configuration
- [ ] Ran diagnostic commands above

---

## 📞 Still Having Issues?

If diffs still don't show after all these checks, provide:

1. **Flask terminal output** (the [PREVIEW] logs)
2. **Browser console output** (the [DEBUG] logs)
3. **Sample of your actual file** (first 50 lines)
4. **Your .env configuration** (NEW_DEFAULT_PLATFORM value)

This will help diagnose the exact issue!
