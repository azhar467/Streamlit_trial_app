from flask import Flask, request, jsonify
from flask_cors import CORS
import threading
from datetime import datetime
import base64
import re
import time

app = Flask(__name__)
CORS(app)

import migration_script as ms

env_config = ms.load_env_config()
PROJECT_NAMES = env_config['projects']

ms.BASE_URL = env_config['base_url']
ms.TOKEN = env_config['token']
ms.NEW_DEFAULT_PLATFORM = env_config['new_default_platform']
ms.REVIEWER_USERNAMES = env_config['reviewer_usernames']
ms.ASSIGNEE_USERNAMES = env_config['assignee_usernames']

active_tasks = {}


@app.route('/')
def index():
    with open('index.html', 'r', encoding='utf-8') as f:
        return f.read()


@app.route('/api/config', methods=['GET'])
def get_config():
    return jsonify({
        'success': True,
        'projects': [{'id': pid, 'name': name} for pid, name in sorted(PROJECT_NAMES.items())],
        'reviewers': env_config['reviewer_usernames'],
        'assignees': env_config['assignee_usernames']
    })


@app.route('/api/projects/<int:project_id>/preview', methods=['POST'])
def preview_changes(project_id):
    try:
        data = request.json
        choices = data.get('choices', [])
        actions = []
        
        if '1' in choices:
            res = ms.api_call(f"projects/{project_id}/repository/files/pom.xml?ref=develop")
            if isinstance(res, dict) and "content" in res:
                orig = base64.b64decode(res['content']).decode('utf-8')
                upd = re.sub(r"<(java\.version|maven\.compiler\.(source|target|release))>11</\1>", r"<\1>17</\1>", orig)
                if "<parent>" in upd:
                    upd = re.sub(r"<parent>[\s\S]*?</parent>", ms.update_parent_block, upd)
                if orig != upd:
                    actions.append({'file_path': 'pom.xml', 'diff': generate_diff(orig, upd)})
        
        if '2' in choices:
            res = ms.api_call(f"projects/{project_id}/repository/files/.gitlab-ci.yml?ref=develop")
            if isinstance(res, dict) and "content" in res:
                orig = base64.b64decode(res['content']).decode('utf-8')
                upd = re.sub(r"^\s*image:.*(\n|$)", "", orig, flags=re.MULTILINE)
                if orig != upd:
                    actions.append({'file_path': '.gitlab-ci.yml', 'diff': generate_diff(orig, upd)})
        
        if '3' in choices:
            path = ".elasticbeanstalk/config.yml"
            res = ms.api_call(f"projects/{project_id}/repository/files/{path}?ref=develop")
            if isinstance(res, dict) and "content" in res:
                orig = base64.b64decode(res['content']).decode('utf-8')
                upd = re.sub(r"(default_platform:\s*).*$", f"default_platform: {ms.NEW_DEFAULT_PLATFORM}", orig, flags=re.MULTILINE)
                if orig != upd:
                    actions.append({'file_path': path, 'diff': generate_diff(orig, upd)})
        
        return jsonify({'success': True, 'actions': actions})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/projects/<int:project_id>/commit', methods=['POST'])
def commit_changes(project_id):
    try:
        data = request.json
        choices = data.get('choices', [])
        
        task_id = f"commit_{project_id}_{int(datetime.now().timestamp())}"
        
        def run_commit():
            try:
                p_name = PROJECT_NAMES.get(project_id, f"Project {project_id}")
                ms.create_feature_branch(project_id, p_name)
                
                actions = []
                current_ref = ms.FEATURE_BRANCH
                
                if '1' in choices:
                    res = ms.api_call(f"projects/{project_id}/repository/files/pom.xml?ref={current_ref}")
                    if isinstance(res, dict) and "content" in res:
                        orig = base64.b64decode(res['content']).decode('utf-8')
                        upd = re.sub(r"<(java\.version|maven\.compiler\.(source|target|release))>11</\1>", r"<\1>17</\1>", orig)
                        if "<parent>" in upd:
                            upd = re.sub(r"<parent>[\s\S]*?</parent>", ms.update_parent_block, upd)
                        if orig != upd:
                            actions.append({"action": "update", "file_path": "pom.xml", "content": upd})
                
                if '2' in choices:
                    res = ms.api_call(f"projects/{project_id}/repository/files/.gitlab-ci.yml?ref={current_ref}")
                    if isinstance(res, dict) and "content" in res:
                        orig = base64.b64decode(res['content']).decode('utf-8')
                        upd = re.sub(r"^\s*image:.*(\n|$)", "", orig, flags=re.MULTILINE)
                        if orig != upd:
                            actions.append({"action": "update", "file_path": ".gitlab-ci.yml", "content": upd})
                
                if '3' in choices:
                    path = ".elasticbeanstalk/config.yml"
                    res = ms.api_call(f"projects/{project_id}/repository/files/{path}?ref={current_ref}")
                    if isinstance(res, dict) and "content" in res:
                        orig = base64.b64decode(res['content']).decode('utf-8')
                        upd = re.sub(r"(default_platform:\s*).*$", f"default_platform: {ms.NEW_DEFAULT_PLATFORM}", orig, flags=re.MULTILINE)
                        if orig != upd:
                            actions.append({"action": "update", "file_path": path, "content": upd})
                
                if actions:
                    commit_payload = {
                        "branch": ms.FEATURE_BRANCH,
                        "commit_message": f"fix: {ms.UPGRADE_TYPE}",
                        "actions": actions
                    }
                    
                    commit_resp = ms.api_call(f"projects/{project_id}/repository/commits", "POST", commit_payload)
                    
                    if isinstance(commit_resp, dict) and not commit_resp.get("error"):
                        active_tasks[task_id] = {'status': 'completed', 'message': 'Committed successfully'}
                    else:
                        active_tasks[task_id] = {'status': 'failed', 'message': 'Commit failed'}
                else:
                    active_tasks[task_id] = {'status': 'completed', 'message': 'No changes to commit'}
                    
            except Exception as e:
                active_tasks[task_id] = {'status': 'failed', 'message': str(e)}
        
        thread = threading.Thread(target=run_commit)
        thread.daemon = True
        thread.start()
        
        active_tasks[task_id] = {'status': 'running', 'message': 'Committing...'}
        
        return jsonify({'success': True, 'task_id': task_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/projects/<int:project_id>/mr', methods=['POST'])
def create_mr(project_id):
    try:
        task_id = f"mr_{project_id}_{int(datetime.now().timestamp())}"
        
        def run_mr():
            try:
                p_name = PROJECT_NAMES.get(project_id, f"Project {project_id}")
                result = ms.create_mr_for_project(project_id, p_name, {'snapshots': []})
                
                if result['success']:
                    active_tasks[task_id] = {'status': 'completed', 'message': f"MR created: {result.get('url', 'N/A')}"}
                else:
                    active_tasks[task_id] = {'status': 'failed', 'message': 'Failed to create MR'}
            except Exception as e:
                active_tasks[task_id] = {'status': 'failed', 'message': str(e)}
        
        thread = threading.Thread(target=run_mr)
        thread.daemon = True
        thread.start()
        
        active_tasks[task_id] = {'status': 'running', 'message': 'Creating MR...'}
        
        return jsonify({'success': True, 'task_id': task_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/projects/<int:project_id>/tags', methods=['GET'])
def get_tags(project_id):
    try:
        tags_resp = ms.fetch_all_tags_for_project(project_id)
        
        if isinstance(tags_resp, dict) and tags_resp.get("error"):
            return jsonify({'success': False, 'error': tags_resp.get('details')}), 500
        
        filter_result = ms.filter_and_sort_deployment_tags(tags_resp)
        
        return jsonify({
            'success': True,
            'tags': filter_result['sorted_tags']
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/projects/<int:project_id>/deploy', methods=['POST'])
def deploy(project_id):
    try:
        data = request.json
        selected_tags = data.get('tags', [])
        
        task_id = f"deploy_{project_id}_{int(datetime.now().timestamp())}"
        
        def run_deploy():
            try:
                p_name = PROJECT_NAMES.get(project_id, f"Project {project_id}")
                branch_info = ms.api_call(f"projects/{project_id}/repository/branches/{ms.FEATURE_BRANCH}")
                feature_head = (branch_info.get("commit") or {}).get("id") if isinstance(branch_info, dict) else None
                
                messages = []
                
                for tag_name in selected_tags:
                    messages.append(f"Processing tag: {tag_name}")
                    
                    tags_resp = ms.fetch_all_tags_for_project(project_id)
                    tag_obj = next((t for t in tags_resp if isinstance(t, dict) and t.get('name') == tag_name), None) if isinstance(tags_resp, list) else None
                    
                    if tag_obj and not tag_obj.get('protected'):
                        ms.api_call(f"projects/{project_id}/repository/tags/{tag_name}", method="DELETE")
                    
                    t_res = ms.api_call(f"projects/{project_id}/repository/tags", "POST", {"tag_name": tag_name, "ref": ms.FEATURE_BRANCH})
                    
                    if isinstance(t_res, dict) and not t_res.get("error"):
                        created_commit = (t_res.get('commit') or {}).get('id')
                        
                        time.sleep(10)
                        
                        pipeline = ms.get_pipeline_for_commit(project_id, created_commit)
                        if pipeline:
                            pipeline_id = pipeline.get('id')
                            messages.append(f"Pipeline {pipeline_id} triggered")
                            
                            result = ms.wait_for_pipeline_completion(project_id, pipeline_id, timeout=1800, check_interval=30)
                            
                            if result['status'] == 'success':
                                messages.append(f"Build succeeded for {tag_name}")
                                
                                jobs = ms.get_pipeline_jobs(project_id, pipeline_id)
                                terminate_job = ms.find_job_by_name(jobs, 'eb-terminate')
                                if terminate_job:
                                    ms.trigger_manual_job(project_id, terminate_job.get('id'))
                                    ms.wait_for_job_completion(project_id, terminate_job.get('id'), timeout=900)
                                    messages.append("Termination completed")
                                
                                deploy_job_name = ms.map_tag_to_deploy_job(tag_name)
                                if deploy_job_name:
                                    jobs = ms.get_pipeline_jobs(project_id, pipeline_id)
                                    deploy_job = ms.find_job_by_name(jobs, deploy_job_name)
                                    if deploy_job:
                                        ms.trigger_manual_job(project_id, deploy_job.get('id'))
                                        deploy_result = ms.wait_for_job_completion(project_id, deploy_job.get('id'), timeout=1200)
                                        
                                        if deploy_result['status'] == 'success':
                                            messages.append(f"✓ Deployment SUCCESS for {tag_name}")
                                        else:
                                            messages.append(f"✗ Deployment FAILED for {tag_name}")
                
                active_tasks[task_id] = {'status': 'completed', 'message': '\n'.join(messages)}
                
            except Exception as e:
                active_tasks[task_id] = {'status': 'failed', 'message': str(e)}
        
        thread = threading.Thread(target=run_deploy)
        thread.daemon = True
        thread.start()
        
        active_tasks[task_id] = {'status': 'running', 'message': 'Starting deployment...'}
        
        return jsonify({'success': True, 'task_id': task_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/bulk-mr', methods=['POST'])
def bulk_mr():
    try:
        data = request.json
        project_ids = data.get('project_ids', [])
        
        task_id = f"bulk_mr_{int(datetime.now().timestamp())}"
        
        def run_bulk():
            try:
                messages = []
                for pid in project_ids:
                    p_name = PROJECT_NAMES.get(pid, f"Project {pid}")
                    messages.append(f"Processing {p_name}...")
                    
                    result = ms.create_mr_for_project(pid, p_name, {'snapshots': []})
                    
                    if result['success']:
                        messages.append(f"✓ MR created for {p_name}")
                    else:
                        messages.append(f"✗ Failed for {p_name}")
                
                active_tasks[task_id] = {'status': 'completed', 'message': '\n'.join(messages)}
                
            except Exception as e:
                active_tasks[task_id] = {'status': 'failed', 'message': str(e)}
        
        thread = threading.Thread(target=run_bulk)
        thread.daemon = True
        thread.start()
        
        active_tasks[task_id] = {'status': 'running', 'message': 'Creating MRs...'}
        
        return jsonify({'success': True, 'task_id': task_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/tasks/<task_id>', methods=['GET'])
def get_task(task_id):
    if task_id in active_tasks:
        return jsonify({'success': True, 'task': active_tasks[task_id]})
    else:
        return jsonify({'success': False, 'error': 'Task not found'}), 404


def generate_diff(old_content, new_content):
    import difflib
    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)
    diff = ''.join(difflib.unified_diff(old_lines, new_lines, fromfile='before', tofile='after', lineterm=''))
    return diff


if __name__ == '__main__':
    print("=" * 60)
    print("  GitLab Migration Tool")
    print("  Server running on http://localhost:5000")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5000, debug=False)
