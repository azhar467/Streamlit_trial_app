@echo off
title GitLab Migration Tool - Enhanced
color 0B

echo.
echo ================================================
echo    GitLab Migration Tool - Enhanced
echo    Java 11 to Java 17 Migration
echo ================================================
echo.

REM Check Python installation
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found!
    echo Please install Python 3.9 or higher from python.org
    echo.
    pause
    exit /b 1
)

echo [INFO] Python found
python --version

REM Check required files
if not exist "migration_script.py" (
    echo.
    echo [ERROR] migration_script.py not found!
    echo Please copy your migration_script.py to this folder
    echo.
    pause
    exit /b 1
)

echo [INFO] migration_script.py found

if not exist ".env" (
    echo.
    echo [ERROR] .env file not found!
    echo Please copy your .env file to this folder
    echo.
    pause
    exit /b 1
)

echo [INFO] .env file found

REM Check and install dependencies
echo.
echo [STEP 1/3] Checking dependencies...
pip show flask >nul 2>&1
if errorlevel 1 (
    echo Installing Flask dependencies...
    pip install -q -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Failed to install dependencies
        pause
        exit /b 1
    )
    echo Dependencies installed successfully!
) else (
    echo Dependencies OK!
)

echo.
echo [STEP 2/3] Starting Flask server...
echo Server will be available at: http://localhost:5000
echo.
echo Logs will be captured in project_state.json
echo.

REM Create log directory if it doesn't exist
if not exist "logs" mkdir logs

REM Start Flask server and capture output to log file
echo [STEP 3/3] Server starting...
echo.

REM Start Flask with output visible in console
start /B python app.py 2>&1 | tee logs\server_%date:~-4,4%%date:~-10,2%%date:~-7,2%.log

REM Wait for server to start
timeout /t 3 /nobreak >nul

REM Open browser
echo Opening browser...
start http://localhost:5000

echo.
echo ================================================
echo    Migration Tool is Running!
echo ================================================
echo.
echo Server URL: http://localhost:5000
echo Server logs: Check console output above
echo Task logs: Check project_state.json
echo.
echo To STOP the server: 
echo   - Close this window, or
echo   - Press Ctrl+C
echo.
echo The server output will appear below:
echo ------------------------------------------------
echo.

REM Keep the window open and show server output
python app.py

REM This line will execute after Ctrl+C
echo.
echo Server stopped.
pause
