# Troubleshooting Guide - GitLab Migration & Orchestrator Tool

## Common Issues and Solutions

---

## Issue 1: Pop-up Not Showing After Commit

### Symptoms:
- Commit succeeds but no success modal appears
- No visual confirmation of commit

### Root Causes & Solutions:

#### A. Check Browser Console
1. Open browser (Chrome/Edge/Firefox)
2. Press **F12** to open Developer Tools
3. Click **Console** tab
4. Look for errors or `[MONITOR]` and `[COMMIT]` messages

**What to look for:**
```
[COMMIT] Starting commit from modal
[COMMIT] Processing project: 101 project-name
[COMMIT] Response from server: {success: true, task_id: "commit_101_..."}
[MONITOR] Starting monitor for task: commit_101_...
[MONITOR] Task status: {success: true, task: {...}}
[MONITOR] Commit completed: {projectName: "...", fileCount: 3, commitSha: "..."}
```

**If you see errors:**
- Red error messages indicate JavaScript issues
- Share the error message for specific help

#### B. Check Server Console
Look at the command prompt window where you ran the batch file:

**What you should see:**
```
[COMMIT] Starting commit for project 101: project-name
[COMMIT] Feature branch: task-12938-java17-migration
[COMMIT] SUCCESS - SHA: a1b2c3d4..., Files: 3
[INFO] Pipeline 123456 triggered
```

**If you don't see these:**
- The commit might not be reaching the server
- Check network errors in browser DevTools → Network tab

#### C. Verify Task Monitoring
In browser console, type:
```javascript
fetch('/api/tasks/commit_101_1234567890')
  .then(r => r.json())
  .then(console.log)
```

**Expected response:**
```json
{
  "success": true,
  "task": {
    "status": "completed",
    "commit_sha": "a1b2c3d4...",
    "file_count": 3,
    "project_name": "project-name",
    "logs": [...]
  }
}
```

**If task not found:**
- Task may have expired (tasks are in-memory only)
- Try committing again

---

## Issue 2: Logs Not Appearing

### Symptoms:
- Logs panel doesn't show up
- Logs panel is empty even after commit
- No "📋 Operation Logs" header

### Solutions:

#### A. Check Logs Container Exists
In browser console:
```javascript
document.getElementById('full-logs')
```

**Should return:** An HTML div element
**If null:** Hard refresh browser (Ctrl+Shift+R)

#### B. Check Logs Are Being Added
In browser console after commit:
```javascript
document.querySelectorAll('#full-logs .log-entry').length
```

**Should return:** Number greater than 0
**If 0:** Logs aren't being added - check monitor logs in console

#### C. Force Show Logs Panel
In browser console:
```javascript
const logsContainer = document.getElementById('full-logs');
logsContainer.classList.add('show');
logsContainer.style.display = 'block';
```

**If logs appear:** CSS issue, hard refresh
**If still nothing:** No logs are being generated

#### D. Check Server Is Sending Logs
In browser DevTools → Network tab:
1. Find the `/api/tasks/commit_...` request
2. Click on it
3. Click **Preview** or **Response** tab
4. Look for `logs` array

**Expected:**
```json
{
  "task": {
    "logs": [
      {"level": "INFO", "message": "Starting commit..."},
      {"level": "SUCCESS", "message": "Commit successful!"}
    ]
  }
}
```

**If logs array is empty:**
- Server isn't creating logs
- Check server console for errors

---

## Issue 3: Log Files Not Creating

### Symptoms:
- No files in `migration_logs` folder
- "View Logs" button shows "No log files found"

### Root Cause:
The file logger isn't initialized or logs directory doesn't exist

### Solutions:

#### A. Check Log Directories Exist
In your project folder, you should have:
```
migration_logs/
rollback_logs/
state_logs/
```

**Create them manually if missing:**
```batch
mkdir migration_logs
mkdir rollback_logs
mkdir state_logs
```

#### B. Check Server Startup Message
When you run the batch file, look for:
```
[INFO] File logging initialized: migration_logs/migration_20260216_143022.log
```

**If you see:**
```
[WARN] Could not initialize file logging: ...
```

Then there's a permission or path issue.

#### C. Check File Permissions
- Ensure you have write permissions to the folder
- Try running command prompt as Administrator
- Check if antivirus is blocking file creation

#### D. Manual Test
In server console (command prompt), type:
```python
python
>>> import migration_script as ms
>>> log_file = ms.setup_file_logging()
>>> print(log_file)
```

**Should print:** Path to log file
**If error:** Shows the specific problem

---

## Issue 4: Header Controls in Wrong Position

### Symptoms:
- "Load Configuration" button not on the right side
- Header looks misaligned

### Solution:
Hard refresh the browser:
- **Chrome/Edge:** Ctrl + Shift + R
- **Firefox:** Ctrl + F5
- **Or:** Ctrl + Shift + Delete → Clear cache

This ensures the latest CSS is loaded.

---

## Issue 5: Pipeline Status Empty

### Symptoms:
- Pipeline panel is empty after commit
- No build status showing

### Root Causes & Solutions:

#### A. Pipeline Panel Not Visible
The pipeline panel auto-hides if there's no data.

**To show it manually:**
```javascript
document.getElementById('pipeline-panel').style.display = 'block';
```

#### B. Check Pipeline Status API
In browser console:
```javascript
fetch('/api/pipeline-status')
  .then(r => r.json())
  .then(console.log)
```

**Expected:**
```json
{
  "success": true,
  "pipelines": {
    "101": {
      "status": "running",
      "pipeline_id": 123456,
      "commit_sha": "a1b2c3d4...",
      "timestamp": "2026-02-16T14:30:00"
    }
  }
}
```

**If pipelines is empty:**
- No commits have been made yet
- Pipeline status wasn't updated

#### C. Force Update Pipeline Status
After a successful commit, in browser console:
```javascript
refreshPipelineStatus()
```

#### D. Check GitLab Pipeline
1. Go to your GitLab project
2. Navigate to CI/CD → Pipelines
3. Check if pipeline was actually triggered

**If no pipeline in GitLab:**
- Check if `.gitlab-ci.yml` exists in your project
- Check if CI/CD is enabled for the project
- Check GitLab runner availability

---

## Issue 6: Batch File Issues

### A. "Python is not recognized"
**Solution:**
1. Install Python 3.7+ from https://www.python.org
2. During installation, check "Add Python to PATH"
3. Restart command prompt
4. Verify: `python --version`

### B. "migration_script.py not found"
**Solution:**
Ensure all files are in the same folder:
```
your-project-folder/
├── app.py
├── index.html
├── migration_script.py  ← Must be present!
├── .env
├── start_migration_tool.bat
└── (other files...)
```

### C. "Module not found: flask"
**Solution:**
```batch
pip install flask flask-cors
```

### D. Port 5000 Already in Use
**Error:** `OSError: [Errno 48] Address already in use`

**Solution:**
1. Close any other Flask apps
2. Or change port in `app.py`:
```python
app.run(host='0.0.0.0', port=5001, debug=False)
```

Then access at http://localhost:5001

---

## Issue 7: "No Changes Detected" When Changes Should Exist

### Symptoms:
- Click Preview
- Get "No changes detected or changes already committed" message
- But you know changes should be there

### Root Cause:
The preview is checking the feature branch, and changes are already there.

### Solutions:

#### A. Verify Feature Branch
The tool creates branches named: `task-{BRANCH_NUM}-java17-migration`

1. Check your GitLab project
2. Look for branch: `task-12938-java17-migration` (or whatever branch number you set)
3. If it exists, changes are already committed!

#### B. Use Different Branch Number
If you want to create NEW changes:
1. Change the "Branch #" field in the header
2. Try a different number (e.g., 12939)
3. This creates a new feature branch
4. Preview will show changes again

#### C. Delete Feature Branch (if needed)
If the feature branch is incorrect:
1. Go to GitLab
2. Repository → Branches
3. Delete the feature branch
4. Try preview again

---

## Debugging Commands Reference

### Browser Console Commands:

```javascript
// Check if modal exists
document.getElementById('commit-success-modal')

// Force show modal (for testing)
showCommitSuccessModal('Test Project', 3, 'a1b2c3d4e5f6')

// Check logs container
document.getElementById('full-logs')

// Force show logs
document.getElementById('full-logs').classList.add('show')

// Check active tasks
fetch('/api/tasks/YOUR_TASK_ID_HERE').then(r => r.json()).then(console.log)

// Check pipeline status
fetch('/api/pipeline-status').then(r => r.json()).then(console.log)

// Check project configuration
fetch('/api/config').then(r => r.json()).then(console.log)

// Check history
fetch('/api/history').then(r => r.json()).then(console.log)

// Enable verbose logging (add to any page)
window.localStorage.setItem('debug', 'true')
```

### Server Console Commands:

While server is running, you can't type commands, but you can:
1. Watch for `[COMMIT]`, `[INFO]`, `[WARN]`, `[ERROR]` messages
2. Press Ctrl+C to stop
3. Restart to apply code changes

---

## Quick Diagnostic Checklist

Run through this when something isn't working:

### ✅ Frontend Checks (Browser):
- [ ] Hard refresh (Ctrl+Shift+R)
- [ ] Check console for errors (F12 → Console)
- [ ] Check network requests (F12 → Network)
- [ ] Verify modal exists: `document.getElementById('commit-success-modal')`
- [ ] Verify logs container: `document.getElementById('full-logs')`

### ✅ Backend Checks (Server Console):
- [ ] Server started successfully
- [ ] See "[INFO] File logging initialized"
- [ ] No Python errors on startup
- [ ] See `[COMMIT]` messages when committing
- [ ] See `[INFO] Pipeline XXX triggered` after commit

### ✅ File System Checks:
- [ ] `app.py` exists
- [ ] `index.html` exists
- [ ] `migration_script.py` exists
- [ ] `.env` file configured correctly
- [ ] Log directories exist:
  - [ ] `migration_logs/`
  - [ ] `rollback_logs/`
  - [ ] `state_logs/`

### ✅ GitLab Checks:
- [ ] GitLab token is valid
- [ ] Token has correct permissions (api, write_repository)
- [ ] Projects exist and are accessible
- [ ] CI/CD is enabled
- [ ] GitLab runners are available

---

## Getting More Help

### Collect This Information:

1. **Browser Console Output** (F12 → Console)
   - Copy all `[COMMIT]` and `[MONITOR]` messages
   - Copy any red errors

2. **Server Console Output** (Command Prompt)
   - Copy all output from when you started the server
   - Include any `[ERROR]` or traceback messages

3. **Network Request Data** (F12 → Network)
   - Find `/api/projects/{id}/commit` request
   - Click on it → Response tab
   - Copy the response

4. **Task Response** (Browser Console)
   ```javascript
   fetch('/api/tasks/YOUR_TASK_ID').then(r => r.json()).then(console.log)
   ```
   - Copy the output

5. **Configuration** (hide sensitive data!)
   - Which browser and version?
   - Python version: `python --version`
   - Windows version
   - Any antivirus software running?

### Share These Files:
- Screenshot of the error
- Browser console log
- Server console log
- `.env` file (REMOVE THE TOKEN FIRST!)

---

## Preventive Maintenance

### Regular Checks:
1. **Keep Python Updated**
   ```batch
   python -m pip install --upgrade pip
   pip install --upgrade flask flask-cors
   ```

2. **Check GitLab Token Expiry**
   - Tokens expire!
   - Create new token if needed
   - Update `.env` file

3. **Clean Old Logs** (optional)
   - `migration_logs/` can grow large
   - Safe to delete old log files
   - Don't delete `project_state.json`

4. **Restart Server** After:
   - Code changes
   - `.env` changes
   - Strange behavior

---

## Emergency Reset

If nothing works and you want to start fresh:

1. **Stop the server** (Ctrl+C)

2. **Backup your configuration:**
   ```batch
   copy .env .env.backup
   copy project_state.json project_state.json.backup
   ```

3. **Delete generated files:**
   ```batch
   del project_state.json
   rmdir /s migration_logs
   rmdir /s rollback_logs  
   rmdir /s state_logs
   ```

4. **Re-download fresh files:**
   - Get latest `app.py`
   - Get latest `index.html`

5. **Restore configuration:**
   ```batch
   copy .env.backup .env
   ```

6. **Start fresh:**
   ```batch
   start_migration_tool.bat
   ```

---

## Success Indicators

You know everything is working when:

1. ✅ Server starts with no errors
2. ✅ Browser loads page at http://localhost:5000
3. ✅ "Load Configuration" loads your projects
4. ✅ Preview shows file changes
5. ✅ Commit shows:
   - Logs panel slides in
   - Logs appear in real-time
   - Success modal pops up with details
   - Pipeline status updates
6. ✅ Log files appear in `migration_logs/`
7. ✅ History shows past operations

---

## Contact & Support

If you're still stuck:
1. Collect the diagnostic information above
2. Take screenshots of the issue
3. Note exact steps to reproduce
4. Check if issue happens in incognito/private mode
5. Try a different browser

Remember: Most issues are either:
- Browser cache (hard refresh fixes)
- Server not running (check command prompt)
- Configuration error (check .env file)
- Network/firewall (check antivirus)

**Happy migrating!** 🚀
