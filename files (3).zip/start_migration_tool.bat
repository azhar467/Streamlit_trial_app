@echo off
echo ============================================================
echo  GitLab Migration ^& Orchestrator Tool
echo  Lincoln Financial Group
echo ============================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH
    echo Please install Python 3.7+ and add it to your PATH
    pause
    exit /b 1
)

REM Check if migration_script.py exists
if not exist "migration_script.py" (
    echo [ERROR] migration_script.py not found in current directory
    echo Please ensure all files are in the same folder:
    echo   - app.py
    echo   - index.html  
    echo   - migration_script.py
    echo   - .env
    pause
    exit /b 1
)

REM Check if .env exists
if not exist ".env" (
    echo [WARN] .env file not found
    echo Creating a template .env file...
    echo.
    echo # GitLab Configuration > .env
    echo BASE_URL=https://your-gitlab-instance.com/api/v4 >> .env
    echo TOKEN=your_gitlab_token_here >> .env
    echo. >> .env
    echo # Projects (format: PROJECT_ID=project-name) >> .env
    echo PROJECT_101=example-project-1 >> .env
    echo PROJECT_102=example-project-2 >> .env
    echo. >> .env
    echo # Platform Configuration >> .env
    echo NEW_DEFAULT_PLATFORM=arn:aws:elasticbeanstalk:region:platform >> .env
    echo. >> .env
    echo # Reviewers and Assignees (comma-separated usernames) >> .env
    echo REVIEWER_USERNAMES=user1,user2 >> .env
    echo ASSIGNEE_USERNAMES=user3,user4 >> .env
    echo.
    echo [INFO] Template .env created. Please edit it with your configuration.
    pause
    exit /b 1
)

REM Install required packages
echo [INFO] Checking required packages...
pip show flask >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Installing Flask...
    pip install flask
)

pip show flask-cors >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Installing Flask-CORS...
    pip install flask-cors
)

echo.
echo [INFO] All dependencies installed
echo.

REM Create log directories
if not exist "migration_logs" mkdir migration_logs
if not exist "rollback_logs" mkdir rollback_logs
if not exist "state_logs" mkdir state_logs

echo [INFO] Log directories ready
echo.

REM Start the Flask server
echo ============================================================
echo  Starting GitLab Migration ^& Orchestrator Tool...
echo  Server will be available at: http://localhost:5000
echo  Press Ctrl+C to stop the server
echo ============================================================
echo.

python app.py

REM If we get here, the server stopped
echo.
echo ============================================================
echo  Server stopped
echo ============================================================
pause
