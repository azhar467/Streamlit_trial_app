# 📦 WHICH FILES TO UPDATE

## ⚠️ CRITICAL - READ THIS FIRST!

### Files in This Folder:

```
outputs/
├── app.py                     ← UPDATE THIS ✅
├── index.html                 ← UPDATE THIS ✅
├── start.bat                  ← UPDATE THIS ✅
└── (documentation files)
```

**NOTICE**: `migration_script.py` is **NOT** included!

---

## ✅ UPDATE THESE FILES

### 1. app.py
**Replace your old app.py with this one**
- Enhanced pipeline status tracking
- Captures committer name and message
- Better error handling
- Rollback endpoint

### 2. index.html
**Replace your old index.html with this one**
- Enhanced pipeline status display
- Shows commit ID, committer, message, time
- Migration state tracking
- Activity log
- Rollback UI
- Better formatting

### 3. start.bat
**Replace your old start.bat with this one**
- No extra CMD window
- Cleaner browser opening

---

## ❌ DO NOT REPLACE THESE

### migration_script.py
**KEEP YOUR ORIGINAL 2400-LINE VERSION!**

**Why?**
- Your version has production logic
- Your version has 2400 lines (customized)
- app.py imports and uses it
- Your version is tested and proven

**What if I don't have it?**
- Check your backup
- Look in your project folder
- It should be ~2400 lines
- Contains functions like: `process_project()`, `handle_deployment()`, etc.

### .env
**KEEP YOUR EXISTING .env FILE!**

**Why?**
- Has your GitLab token
- Has your project configurations
- Has your settings
- Don't overwrite it!

---

## 📋 Update Instructions

### Step 1: Backup Current Files
```bash
# Backup your current files first!
copy app.py app.py.backup
copy index.html index.html.backup
copy start.bat start.bat.backup
```

### Step 2: Verify You Have These
```bash
# Make sure these exist and DON'T replace them:
migration_script.py    (should be ~2400 lines)
.env                   (should have your settings)
```

### Step 3: Copy New Files
```bash
# Copy from outputs folder:
copy outputs/app.py .
copy outputs/index.html .
copy outputs/start.bat .
```

### Step 4: Verify Structure
```
your-project/
├── app.py              ← NEW (from outputs)
├── index.html          ← NEW (from outputs)
├── start.bat           ← NEW (from outputs)
├── migration_script.py ← YOUR ORIGINAL (DON'T TOUCH!)
└── .env                ← YOUR CONFIG (DON'T TOUCH!)
```

---

## 🔍 Quick Verification

After updating, check:

```bash
# Check app.py has new function:
grep "committer_name" app.py
# Should find: def update_pipeline_status(..., committer_name=None, ...)

# Check index.html has enhanced display:
grep "Committer:" index.html
# Should find: 👤 Committer:

# Check migration_script.py is yours:
wc -l migration_script.py
# Should show: ~2400 lines (your version)
```

---

## ⚠️ Common Mistakes

### ❌ WRONG:
```
Replaced migration_script.py
→ Lost custom logic!
→ Functions don't work!
→ app.py can't import!
```

### ✅ CORRECT:
```
Kept migration_script.py
Updated app.py, index.html, start.bat
Everything works!
```

---

## 🎯 What Each File Does

### app.py (UPDATE)
- Flask web server
- API endpoints
- Imports your migration_script.py
- Handles web requests
- Tracks pipeline status

### index.html (UPDATE)
- Web interface
- Shows pipeline status
- User interactions
- Displays all information

### start.bat (UPDATE)
- Launches the tool
- Starts Flask server
- Opens browser

### migration_script.py (KEEP YOURS!)
- Core migration logic
- GitLab API calls
- Commit operations
- Deploy functions
- Your custom code

### .env (KEEP YOURS!)
- GitLab credentials
- Project definitions
- Configuration settings

---

## 🚀 After Updating

### Test Everything:
1. ✅ Server starts (run start.bat)
2. ✅ Browser opens to tool
3. ✅ Click "Load Config" - projects load
4. ✅ Commit a change
5. ✅ Pipeline status appears with ALL details:
   - Commit ID ✅
   - Committer name ✅
   - Commit message ✅
   - Date/time ✅
   - Pipeline ID ✅

---

## 📞 If Something Goes Wrong

### Problem: "Cannot import migration_script"
**Solution**: You have the right migration_script.py, right?

### Problem: "Pipeline status missing details"
**Solution**: Make sure you updated app.py AND index.html

### Problem: "Functions not found"
**Solution**: Your migration_script.py has all the functions, right?

### Problem: "Nothing works"
**Solution**: Did you replace migration_script.py by mistake?

---

## ✅ Final Checklist

Before running:
- [ ] Backed up old files
- [ ] Updated app.py
- [ ] Updated index.html  
- [ ] Updated start.bat
- [ ] Kept original migration_script.py (~2400 lines)
- [ ] Kept original .env file
- [ ] Verified file structure

After running:
- [ ] Server starts
- [ ] Browser opens
- [ ] Projects load
- [ ] Pipeline status shows all details
- [ ] No errors in console

---

## 🎉 You're Ready!

**What you updated**:
- ✅ app.py (web server)
- ✅ index.html (interface)
- ✅ start.bat (launcher)

**What you kept**:
- ✅ migration_script.py (your 2400-line version!)
- ✅ .env (your configuration)

**What you got**:
- ✅ Full pipeline details
- ✅ Committer information
- ✅ Enhanced display
- ✅ All features working

**Ready to migrate!** 🚀
