# GitLab Migration Tool - Refactored UI/UX

## 🎨 Overview

This refactored version includes significant UI/UX improvements with modern glassmorphism effects, better typography, and a restructured panel layout for improved workflow.

---

## ✨ Key Changes

### 1. **UI & Style Improvements**

#### Typography
- **UI Elements**: Now using **'Inter'** font family for a clean, modern interface
- **Code/Logs**: Using **'JetBrains Mono'** monospace font for better code readability

#### Glassmorphism Effects
- **Header**: Semi-transparent background with `backdrop-filter: blur(12px)`
- **Panels**: Frosted glass effect on all cards with subtle transparency
- **Pipeline Status Panel**: Enhanced with glassmorphism for modern look

#### Visual Enhancements
- **Borders**: Semi-transparent borders using `rgba(255,255,255,0.05)` for depth
- **Soft Glows**: Active states now use soft box-shadow glows instead of hard borders
  - Primary glow: `rgba(108, 99, 255, 0.4)`
  - Success glow: `rgba(0, 217, 163, 0.4)`
  - Danger glow: `rgba(255, 107, 107, 0.4)`
- **Enhanced Diff View**: 
  - Better padding and spacing
  - Matching line heights
  - Softer color scheme for additions/removals
  - Border indicators on changed lines

---

### 2. **Panel Restructure**

#### Left Panel: Full Migration (Enhanced)
- **Projects selection**
- **File update options**
- **Preview & Create MR buttons**
- **NEW: 🚀 Create Tag & Deploy button**
  - Disabled by default
  - **Only enables after successful Maven build/pipeline**
  - Provides quick tag creation and deployment for successful builds

#### Middle Panel: Tag & Deploy (Moved from Right)
- **Project selection (radio buttons)**
- **Load Tags functionality**
- **Missing Environment Tags Detection**
  - Automatically detects if `azure-dev`, `dev`, `azure-test`, or `test` tags are missing
  - Shows warning box with missing tags
  - Auto-detects which tag should be created based on existing tags
    - If dev tags exist → suggests test tags
    - If no dev tags → suggests dev tags
- **Create Standard Tags**
  - Input field (auto-populated with suggested tag)
  - Button to create the missing environment tags
- **Deploy button**

#### Right Panel: Bulk Operations (Moved from Middle)
- **Bulk project selection with Select All button**
- **Assignees selection with Select All button**
- **Reviewers selection with Select All button**
- **Create MRs in bulk**
- **Operation logs**

---

### 3. **Select All Functionality**

All panels with checkbox lists now include a **"Select All"** button:

**Full Migration Panel:**
- Select All for projects

**Tag & Deploy Panel:**
- N/A (uses radio buttons for single project selection)

**Bulk Operations Panel:**
- Select All for projects
- Select All for assignees
- Select All for reviewers

**Select All Behavior:**
- First click: Selects all checkboxes
- Second click: Deselects all checkboxes (toggle)

---

### 4. **Assignees & Reviewers**

The Bulk Operations panel includes full support for assignees and reviewers:

**Features:**
- Load assignees and reviewers from `.env` configuration
- Select multiple assignees and reviewers
- Quick "Select All" for batch selection
- Included in bulk MR creation API call

**API Integration:**
```javascript
POST /api/bulk-mr
{
  "project_ids": [123, 456],
  "branch_num": "12938",
  "assignees": ["user1", "user2"],
  "reviewers": ["reviewer1", "reviewer2"]
}
```

---

### 5. **New Tag & Deploy Features**

#### Missing Tags Detection
```javascript
// Checks for these required tags:
const requiredTags = ['azure-dev', 'dev', 'azure-test', 'test'];
```

When tags are loaded:
1. System checks if any required tags are missing
2. If missing, displays a warning box with:
   - List of missing tags
   - Auto-suggested tag based on existing tags
3. Pre-populates the input field with the suggested tag

#### Smart Tag Suggestion Logic
```javascript
// If dev tags exist, suggest test tags
if (existingTags.includes('azure-dev') || existingTags.includes('dev')) {
    suggestedTag = 'azure-test' or 'test'
} else {
    suggestedTag = 'azure-dev' or 'dev'
}
```

#### Create Standard Tags
- One-click button to create missing environment tags
- Uses GitLab API to create tags on the `develop` branch (configurable)
- Automatically refreshes tag list after creation

---

### 4. **Enhanced Full Migration Panel**

#### New "Create Tag & Deploy" Button
- **Location**: Left panel, below "Create MR" button
- **Behavior**:
  - Disabled by default
  - Monitors pipeline status
  - **Enables only when pipeline succeeds**
  - Allows quick deployment after successful build
  
#### Workflow Integration
1. User commits changes → Pipeline starts
2. Button remains disabled during pipeline execution
3. Pipeline succeeds → Button auto-enables
4. User clicks → Automatically selects first available environment tag and starts deployment

---

### 5. **API Enhancements**

#### New Endpoint: POST /api/projects/{id}/tags
```javascript
// Create a new tag
POST /api/projects/123/tags
{
  "tag_name": "azure-dev",
  "ref": "develop"
}
```

**Response:**
```json
{
  "success": true,
  "tag": {
    "name": "azure-dev",
    "commit": {...}
  }
}
```

---

## 🎯 CSS Variables

### Color Palette
```css
--primary: #6C63FF              /* Purple */
--primary-glow: rgba(108, 99, 255, 0.4)
--success: #00D9A3              /* Teal */
--success-glow: rgba(0, 217, 163, 0.4)
--danger: #FF6B6B               /* Coral/Red */
--danger-glow: rgba(255, 107, 107, 0.4)
--warning: #FFB800              /* Amber */
--warning-glow: rgba(255, 184, 0, 0.4)
--bg-dark: #0F1419              /* Dark background */
--bg-card: #1A1F2E              /* Card background */
--border: rgba(255, 255, 255, 0.05)
--border-bright: rgba(255, 255, 255, 0.1)
```

### Typography
```css
font-family: 'Inter', system-ui, sans-serif;           /* UI */
font-family: 'JetBrains Mono', monospace;              /* Code */
```

---

## 📋 Button State Logic

### Create Tag & Deploy Button (Full Migration Panel)

```javascript
// Initial State
disabled: true
title: "Enable after successful pipeline"

// After Pipeline Success
disabled: false
title: ""
style: Fully functional with glow effect

// Pipeline Running
disabled: true
title: "Wait for pipeline to complete"

// Pipeline Failed
disabled: true
title: "Pipeline failed"
```

### Create MR Button (Unchanged Behavior)
- Same pipeline-dependent logic as before
- Enables after successful pipeline

---

## 🚀 Usage Guide

### 1. Load Configuration
Click "⚙️ Load Configuration" to load projects from your `.env` file.

### 2. Full Migration with Tag & Deploy

**Option A: Traditional Workflow**
1. Select project(s)
2. Choose files to update
3. Click "👁️ Preview"
4. Review changes in modal
5. Click "✅ Commit Changes"
6. Wait for pipeline to succeed
7. Click "🔀 Create MR"

**Option B: Quick Deploy Workflow** (NEW)
1. Select project(s)
2. Choose files to update
3. Click "👁️ Preview"
4. Commit changes
5. Wait for pipeline to succeed
6. Click **"🚀 Create Tag & Deploy"** (auto-enabled)
7. Automatically deploys to first available environment

### 3. Tag & Deploy Panel (Middle)

1. Select a project (radio button)
2. Click "📋 Load Tags"
3. **If missing environment tags:**
   - Warning box appears
   - Shows suggested tag name
   - Click "➕ Create Standard Tags"
4. Select tags for deployment
5. Click "🚀 Deploy"

### 4. Bulk Operations (Right)

1. Select multiple projects (or use "Select All")
2. Select assignees (or use "Select All")
3. Select reviewers (or use "Select All")
4. Click "🚀 Create MRs"
5. Monitor bulk operation logs

**Pro Tip:** Use "Select All" buttons to quickly select all items in each section.

---

## 🎨 Visual Improvements Summary

### Before → After

| Feature | Before | After |
|---------|--------|-------|
| **Typography** | Segoe UI | Inter (UI) + JetBrains Mono (code) |
| **Panel Backgrounds** | Solid color | Glassmorphism with blur |
| **Borders** | Hard borders | Semi-transparent soft borders |
| **Active States** | Border highlight | Soft glows |
| **Diff View** | Basic | Enhanced with better spacing |
| **Warning Messages** | Basic alerts | Styled warning boxes |
| **Tag Management** | Manual only | Auto-detection + creation |
| **Select All** | ❌ None | ✅ All checkbox sections |
| **Assignees/Reviewers** | Bulk panel only | ✅ Preserved in Bulk panel |

---

## 📝 JavaScript Functions

### Key Functions (Maintained Compatibility)

All original function names are preserved:
- `loadConfiguration()`
- `renderProjects()`
- `filterProjects(panel)`
- `previewFullMigration()`
- `createMRFullMigration()`
- `selectDeployProject(projectId)`
- `loadTags()`
- `startDeployment()`
- `createBulkMRs()`
- `monitorTask()`
- `refreshPipelineStatus()`
- `updateButtonStates()`

### New Functions

- `selectAll(className)` - Toggles all checkboxes in a section
- `checkMissingTags(tags)` - Detects missing environment tags
- `createStandardTags()` - Creates missing tags via API
- `createTagAndDeploy()` - New button functionality for quick deploy

### Enhanced Functions

- `createBulkMRs()` - Now includes assignees and reviewers
- `renderProjects()` - Now also renders assignees and reviewers lists
- `getSelected(className)` - Updated to handle both numeric IDs and string values

---

## 🔧 Configuration

### Required Backend Updates

The `app.py` has been updated with:

1. **Enhanced Tags Endpoint**
   ```python
   @app.route('/api/projects/<int:project_id>/tags', methods=['GET', 'POST'])
   ```
   - GET: Returns tags for a project
   - POST: Creates a new tag

### No Breaking Changes

All existing API endpoints remain unchanged. The new features are additive.

---

## 🌐 Browser Compatibility

### Glassmorphism Support
```css
backdrop-filter: blur(12px);           /* Modern browsers */
-webkit-backdrop-filter: blur(12px);   /* Safari */
```

**Supported:**
- Chrome 76+
- Firefox 103+
- Safari 9+
- Edge 79+

**Fallback:**
- Browsers without backdrop-filter support will show solid backgrounds
- All functionality remains intact

---

## 📦 File Structure

```
enhanced_ui/
├── index.html          # Refactored UI with all improvements
├── app.py              # Enhanced backend with tag creation endpoint
├── requirements.txt    # Dependencies (unchanged)
└── README.md           # This file
```

---

## 🎯 Migration Checklist

To use the refactored version:

- [x] Copy `index.html` to your project directory
- [x] Copy `app.py` to your project directory
- [x] Ensure `migration_script.py` is in the same directory
- [x] Ensure `.env` file is configured
- [x] Run `python app.py`
- [x] Open `http://localhost:5000`
- [x] Test the new Tag & Deploy features

---

## 🐛 Known Considerations

1. **Tag Creation**: Requires proper GitLab API permissions
2. **Pipeline Monitoring**: Continues to use 5-second polling interval
3. **Browser Support**: Glassmorphism effects may not render in older browsers (functionality remains)

---

## 💡 Tips

1. **Use Create Tag & Deploy** for quick iteration cycles after successful builds
2. **Monitor Missing Tags** in the Tag & Deploy panel before deployment
3. **Glassmorphism works best** on high-contrast displays
4. **JetBrains Mono** provides excellent readability for logs and diffs

---

## 📧 Support

For issues or questions:
1. Check browser console for JavaScript errors
2. Verify GitLab API permissions
3. Ensure all required files are in place
4. Check pipeline status for timing issues

---

**Enjoy your enhanced GitLab Migration Tool!** 🚀✨
