# GitLab Migration & Orchestrator Tool - URL Fixes Summary

## Issues Identified and Fixed

### **Root Cause**
The frontend (index.html) was calling incorrect API endpoints that didn't match the backend (app.py) route definitions. Additionally, URL encoding was missing for branch names, tag names, and ref parameters, which would cause failures when these contained special characters like `/` or `-`.

---

## Changes Made to `index.html` (2283 → 2318 lines)

### 1. **Fixed Commit Function** (Line ~1642)
**Problem:** Was calling `/api/commit` which doesn't exist in backend
**Solution:** Now calls `/api/projects/{projectId}/commit` for each project individually

**Before:**
```javascript
const response = await fetch('/api/commit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ preview_data: previewData, branch_num })
});
```

**After:**
```javascript
// Commit each project sequentially
for (const projectData of previewData) {
    const projectId = projectData.projectId;
    const projectName = projectData.project;
    
    const response = await fetch(`/api/projects/${projectId}/commit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ choices, branch_num })
    });
    // ... error handling per project
}
```

### 2. **Fixed MR Creation in Full Migration Mode** (Line ~1685)
**Problem:** Was calling `/api/mr` which doesn't exist
**Solution:** Now calls `/api/projects/{projectId}/mr` for each project

**Before:**
```javascript
const response = await fetch('/api/mr', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ project_ids: projectIds, branch_num })
});
```

**After:**
```javascript
// Create MR for each project
for (const projectId of projectIds) {
    const response = await fetch(`/api/projects/${projectId}/mr`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ branch_num })
    });
    // ... per-project handling
}
```

### 3. **Fixed Deploy Function** (Line ~1815)
**Problem:** Was calling `/api/deploy` without project_id in URL path
**Solution:** Now calls `/api/projects/{selectedDeployProject}/deploy`

**Before:**
```javascript
const response = await fetch('/api/deploy', {
    method: 'POST',
    body: JSON.stringify({ 
        project_id: selectedDeployProject,  // Wrong: in body instead of URL
        tags: selectedTags,
        create_mr_on_success: false
    })
});
```

**After:**
```javascript
const response = await fetch(`/api/projects/${selectedDeployProject}/deploy`, {
    method: 'POST',
    body: JSON.stringify({ 
        tags: selectedTags,
        create_mr_on_success: false,
        branch_num: branch_num
    })
});
```

### 4. **Fixed Auto-Deploy Function** (Line ~1909)
**Problem:** Same issue - using wrong endpoint for deployment
**Solution:** Uses correct endpoint with proper error handling

**Before:**
```javascript
const deployResponse = await fetch('/api/deploy', {
    body: JSON.stringify({ 
        project_id: projectId,
        tags: [tagName],
        create_mr_on_success: false
    })
});
```

**After:**
```javascript
const deployResponse = await fetch(`/api/projects/${projectId}/deploy`, {
    body: JSON.stringify({ 
        tags: [tagName],
        create_mr_on_success: false,
        branch_num: branch_num
    })
});
```

---

## Changes Made to `app.py` (854 → 862 lines)

### 1. **Added URL Encoding Import** (Line ~10)
**Added:**
```python
import urllib.parse
```

### 2. **Fixed Preview Endpoint - URL Encoding** (Lines ~132-221)
**Problem:** Branch refs and file paths weren't URL-encoded
**Solution:** Added proper URL encoding for all ref parameters

**Fixed locations:**
- Line ~134: `pom.xml` file fetch
- Line ~178: `.gitlab-ci.yml` file fetch  
- Line ~221: `.elasticbeanstalk/config.yml` file fetch

**Example fix:**
```python
# Before
res = ms.api_call(f"projects/{project_id}/repository/files/pom.xml?ref={branch}")

# After
encoded_ref = urllib.parse.quote(branch, safe='')
res = ms.api_call(f"projects/{project_id}/repository/files/pom.xml?ref={encoded_ref}")
```

### 3. **Fixed Commit Endpoint - URL Encoding** (Lines ~300-330)
**Problem:** Same URL encoding issues in commit operations
**Solution:** Added URL encoding for all ref parameters

**Fixed for:**
- pom.xml fetching (line ~301)
- .gitlab-ci.yml fetching (line ~312)
- .elasticbeanstalk/config.yml fetching (line ~323)

### 4. **Fixed Deploy Endpoint - URL Encoding** (Lines ~558-582)
**Problem:** Branch names and tag names weren't URL-encoded
**Solution:** Added encoding for branch names and tag names

**Branch encoding (line ~558):**
```python
# Before
branch_info = ms.api_call(f"projects/{project_id}/repository/branches/{ms.FEATURE_BRANCH}")

# After
encoded_branch = urllib.parse.quote(ms.FEATURE_BRANCH, safe='')
branch_info = ms.api_call(f"projects/{project_id}/repository/branches/{encoded_branch}")
```

**Tag encoding (line ~578):**
```python
# Before
ms.api_call(f"projects/{project_id}/repository/tags/{tag_name}", method="DELETE")

# After
encoded_tag = urllib.parse.quote(tag_name, safe='')
ms.api_call(f"projects/{project_id}/repository/tags/{encoded_tag}", method="DELETE")
```

---

## Why These Changes Fix the Issues

### **Correct API Endpoints**
1. The backend defines routes like `/api/projects/<int:project_id>/commit`
2. The frontend was calling `/api/commit` (wrong!)
3. Now frontend matches backend route structure exactly

### **URL Encoding**
1. GitLab API requires URL-encoded parameters for:
   - Branch names (e.g., `task-1293-java17-migration` → `task-1293-java17-migration`)
   - Tag names (e.g., `azure-dev` → `azure-dev`)
   - Ref parameters (any special characters)
2. Without encoding, requests with special characters would fail
3. Using `urllib.parse.quote(value, safe='')` ensures proper encoding

### **Proper Payload Structure**
1. Backend expects specific JSON payload structures
2. Frontend now sends exactly what backend expects
3. Project IDs are now in URL path (RESTful design) not in body

---

## Testing Recommendations

### 1. **Test Commit Flow**
- Select one or more projects in Full Migration tab
- Check file changes (POM, CI, EB)
- Click Preview
- Click "Commit Changes" in the modal
- **Expected:** Each project commits individually with success messages

### 2. **Test MR Creation**
- After commits succeed
- Click "Create MR" button
- **Expected:** MRs created for each selected project

### 3. **Test Deployment**
- Select a project in Tag & Deploy tab
- Load tags
- Select environment tags (dev, test, etc.)
- Click "Start Deployment"
- **Expected:** Tags created and pipelines triggered

### 4. **Test with Special Characters**
- Use branch names with hyphens: `task-1234-migration` ✓
- Use tag names like `azure-dev` ✓
- **Expected:** All operations work correctly

---

## No Other Changes Required

✅ **No changes needed to:**
- `.env` file
- `migration_script.py` (imported module)
- Database or state files
- GitLab configuration

✅ **The tool name remains:** GitLab Migration & Orchestrator Tool

✅ **All functionality preserved:**
- Preview changes
- Commit to feature branches
- Create merge requests
- Tag and deploy to environments
- Bulk operations
- History tracking
- Log viewing

---

## Quick Verification Checklist

- [ ] Can preview file changes without errors
- [ ] Can commit changes to feature branch
- [ ] Commit status shows in activity panel
- [ ] Can create MRs after successful commits
- [ ] Can load tags for deployment
- [ ] Can trigger deployments successfully
- [ ] Pipeline status updates correctly
- [ ] Error messages are clear and helpful

---

## File Sizes
- **app.py:** 854 lines → 862 lines (+8 lines for imports and encoding)
- **index.html:** 2283 lines → 2318 lines (+35 lines for proper async loops and error handling)
