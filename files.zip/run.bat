@echo off
echo ==========================================
echo GitLab Migration Tool - Web UI
echo ==========================================
echo.

REM Check if .env exists
if not exist .env (
    echo [91m.env file not found![0m
    echo.
    echo Creating .env from example...
    copy .env.example .env
    echo.
    echo [92mCreated .env file[0m
    echo [93mPlease edit .env with your GitLab token and projects[0m
    echo.
    echo Then run this script again!
    pause
    exit /b 1
)

REM Check if virtual environment exists
if not exist venv (
    echo [96mCreating virtual environment...[0m
    python -m venv venv
    echo [92mVirtual environment created[0m
    echo.
)

REM Activate virtual environment
echo [96mActivating virtual environment...[0m
call venv\Scripts\activate.bat

REM Install dependencies
echo [96mInstalling dependencies...[0m
pip install -q -r requirements.txt

echo.
echo ==========================================
echo [92mStarting Migration Tool...[0m
echo ==========================================
echo.
echo Open your browser to: http://localhost:5000
echo.
echo Press Ctrl+C to stop the server
echo.

REM Run the application
python app.py
