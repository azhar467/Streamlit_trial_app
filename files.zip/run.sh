#!/bin/bash

echo "=========================================="
echo "GitLab Migration Tool - Web UI"
echo "=========================================="
echo ""

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "⚠️  .env file not found!"
    echo ""
    echo "Creating .env from example..."
    cp .env.example .env
    echo ""
    echo "✅ Created .env file"
    echo "📝 Please edit .env with your GitLab token and projects"
    echo ""
    echo "Then run this script again!"
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
    echo "✅ Virtual environment created"
    echo ""
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "📦 Installing dependencies..."
pip install -q -r requirements.txt

echo ""
echo "=========================================="
echo "🚀 Starting Migration Tool..."
echo "=========================================="
echo ""
echo "Open your browser to: http://localhost:5000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

# Run the application
python app.py
