# Quick Start Guide 🚀

## 5-Minute Setup

### 1. Extract Files
Extract all files to a folder on your computer.

### 2. Get Your GitLab Token
1. Go to your GitLab instance
2. Click your profile → Settings → Access Tokens
3. Create a new token with these scopes:
   - ✅ api
   - ✅ read_repository
   - ✅ write_repository
4. Copy the token (you'll need it in the next step)

### 3. Configure
1. Copy `.env.example` to `.env`
2. Edit `.env` and add:
   - Your GitLab token
   - Your GitLab URL
   - Your project IDs and names

Example `.env`:
```
GITLAB_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx
BASE_URL=https://gitlab.mycompany.com

PROJECT_101=user-auth-service
PROJECT_102=payment-api
PROJECT_103=notification-service
```

### 4. Run

**Linux/Mac:**
```bash
chmod +x run.sh
./run.sh
```

**Windows:**
```
run.bat
```

### 5. Open Browser
Navigate to: `http://localhost:5000`

## First Migration

1. Click **"Load Config"** - This connects to GitLab and loads your projects
2. **Select projects** - Click projects you want to migrate
3. **Choose files** - Select which files to update (all checked by default)
4. Click **"Preview Changes"** - See what will change (optional but recommended!)
5. Click **"Start Migration"** - Watch the magic happen! ✨

## What Happens?

The tool will:
- ✅ Update Java version from 11 to 17 in `pom.xml`
- ✅ Remove image references from `.gitlab-ci.yml`
- ✅ Update ElasticBeanstalk platform to Corretto 17
- ✅ Create a feature branch
- ✅ Commit changes (if auto-commit is enabled)

## Tips

- Start with 1-2 projects to test
- Use **Preview** before your first migration
- Watch the **live logs** during migration
- The stats at the top show your progress

## Need Help?

Check the full README.md for detailed documentation!

---

Happy Migrating! 🎉
