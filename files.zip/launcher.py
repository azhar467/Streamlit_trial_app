"""
GitLab Migration Tool Launcher
Alternative launcher if START.bat doesn't work
"""

import sys
import os
import subprocess
import time
import webbrowser

def print_header():
    print("=" * 60)
    print("  GitLab Migration Tool - Enhanced")
    print("=" * 60)
    print()

def check_python():
    print("[Step 1/5] Checking Python version...")
    version = sys.version_info
    print(f"[OK] Python {version.major}.{version.minor}.{version.micro}")
    
    if version.major < 3 or (version.major == 3 and version.minor < 9):
        print("[WARNING] Python 3.9+ recommended, you have Python {}.{}.{}".format(
            version.major, version.minor, version.micro))
    print()

def check_files():
    print("[Step 2/5] Checking required files...")
    required_files = {
        'app.py': 'Flask backend',
        'index.html': 'Web interface',
        'migration_script.py': 'Migration script (YOUR FILE)',
        '.env': 'Configuration (YOUR FILE)',
        'requirements.txt': 'Dependencies'
    }
    
    missing = []
    for filename, description in required_files.items():
        if os.path.exists(filename):
            print(f"[OK] {filename} found ({description})")
        else:
            print(f"[ERROR] {filename} NOT FOUND ({description})")
            missing.append(filename)
    
    print()
    
    if missing:
        print("MISSING FILES:")
        for f in missing:
            print(f"  - {f}")
        print()
        
        if 'migration_script.py' in missing:
            print("Please copy migration_script.py to this folder:")
            print(f"  {os.getcwd()}")
            print()
        
        if '.env' in missing:
            print("Please copy .env to this folder:")
            print(f"  {os.getcwd()}")
            print()
        
        input("Press Enter to exit...")
        sys.exit(1)

def check_dependencies():
    print("[Step 3/5] Checking dependencies...")
    
    try:
        import flask
        print("[OK] Flask is installed")
    except ImportError:
        print("[INFO] Flask not installed, installing now...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
            print("[OK] Dependencies installed successfully!")
        except subprocess.CalledProcessError:
            print("[ERROR] Failed to install dependencies!")
            print()
            print("Please try manually:")
            print(f"  {sys.executable} -m pip install Flask flask-cors")
            print()
            input("Press Enter to exit...")
            sys.exit(1)
    
    try:
        import flask_cors
        print("[OK] Flask-CORS is installed")
    except ImportError:
        print("[INFO] Flask-CORS not installed, installing now...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "flask-cors"])
            print("[OK] Flask-CORS installed!")
        except subprocess.CalledProcessError:
            print("[ERROR] Failed to install Flask-CORS!")
    
    print()

def start_server():
    print("[Step 4/5] Starting Flask server...")
    print()
    print("Server will be available at: http://localhost:5000")
    print()
    print("=" * 60)
    print("KEEP THIS WINDOW OPEN!")
    print("=" * 60)
    print()
    print("To stop the server: Press Ctrl+C in this window")
    print()
    
    # Wait a moment
    time.sleep(2)
    
    # Open browser
    print("[Step 5/5] Opening browser...")
    time.sleep(2)
    webbrowser.open('http://localhost:5000')
    
    print()
    print("=" * 60)
    print("Server is running! Browser should open automatically.")
    print("If not, manually go to: http://localhost:5000")
    print("=" * 60)
    print()
    print("Server logs will appear below:")
    print("-" * 60)
    print()
    
    # Start the Flask app
    try:
        # Import and run the Flask app
        import app as flask_app
        # The app.run() call is in the if __name__ == '__main__' block in app.py
        # So we need to run it directly
        os.system(f"{sys.executable} app.py")
    except KeyboardInterrupt:
        print()
        print()
        print("=" * 60)
        print("Server stopped by user (Ctrl+C)")
        print("=" * 60)
    except Exception as e:
        print()
        print(f"[ERROR] Server error: {e}")
        print()
        import traceback
        traceback.print_exc()
        print()
        input("Press Enter to exit...")
        sys.exit(1)

def main():
    print_header()
    check_python()
    check_files()
    check_dependencies()
    start_server()
    
    print()
    input("Press Enter to exit...")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print()
        print("Cancelled by user")
        sys.exit(0)
    except Exception as e:
        print()
        print(f"[ERROR] Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        print()
        input("Press Enter to exit...")
        sys.exit(1)
